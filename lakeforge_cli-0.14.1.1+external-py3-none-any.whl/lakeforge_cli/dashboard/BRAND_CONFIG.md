# Brand Configuration Reference

**Feature**: 021-dashboard-databricks-branding (WP01)
**Purpose**: Lakeforge dashboard branding with Databricks design system

---

## Overview

The Lakeforge dashboard uses `brand-config.json` to customize the project name, color palette, typography, and assets. This enables rebranding from "Lakeforge" to "Lakeforge" with Databricks styling while maintaining upstream compatibility.

## File Location

```
src/specify_cli/dashboard/
├── brand-config.json        # Brand configuration data
├── brand-config.schema.json # JSON Schema v7 validation
└── BRAND_CONFIG.md          # This documentation file
```

## Endpoint

**URL**: `GET /brand-config.json`
**Content-Type**: `application/json`
**Cache-Control**: `no-cache`

The dashboard serves `brand-config.json` at the root level for JavaScript fetch on page load.

**Example fetch**:
```javascript
const response = await fetch('/brand-config.json');
const config = await response.json();
console.log(config.project_name); // "Lakeforge"
```

## Schema Structure

### Top-Level Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `project_name` | string | Yes | Display name (e.g., "Lakeforge") |
| `version` | string | Yes | Brand config version (semantic versioning) |
| `colors` | object | Yes | Color palette (Databricks design system) |
| `typography` | object | Yes | Font settings (system fonts only) |
| `assets` | object | Yes | Logo and favicon paths |
| `metadata` | object | No | Optional metadata (author, created_at, description) |

### Colors Object

**Required colors**:
- `primary`: Primary brand color (Databricks orange `#FF6F00`)
- `background`: Main background (dark theme `#0D1117`)
- `text_primary`: Primary text color (WCAG AA compliant `#E6EDF3`)

**Optional colors**:
- `primary_dark`, `primary_light`, `accent`: Primary color variants
- `surface`, `border`: UI element backgrounds and borders
- `text_secondary`, `text_muted`: Text hierarchy colors
- `success`, `warning`, `error`, `info`: Semantic status colors

**Format**: Hex color codes (`#RRGGBB`, 6 digits)

**WCAG AA Compliance**:
- `text_primary` on `background`: 11.8:1 contrast ratio (exceeds 4.5:1 requirement)
- `text_secondary` on `background`: 6.2:1 contrast ratio (exceeds 4.5:1 requirement)

### Typography Object

**Required fields**:
- `font_family_base`: Base font stack (system fonts, no external dependencies)
- `font_size_base`: Base font size (e.g., `"16px"`)

**Optional fields**:
- `font_family_mono`: Monospace font stack for code blocks
- `font_size_*`: Heading and text size variants (h1, h2, h3, small, code)
- `font_weight_*`: Font weight values (normal, medium, semibold, bold)
- `line_height_*`: Line height values (tight, normal, loose)

**System Font Stack** (no external fonts):
```
-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif
```

### Assets Object

**Required fields**:
- `logo`: Path to logo asset (e.g., `"/static/lakeforge-logo.svg"`)

**Optional fields**:
- `favicon`: Path to favicon asset (e.g., `"/static/lakeforge-favicon.png"`)

**Supported formats**:
- Logo: SVG, PNG, JPG, JPEG
- Favicon: SVG, PNG, ICO

**Note**: Asset paths must be absolute paths starting with `/`. Static assets are served from `/static/` directory.

## Example Configuration

```json
{
  "project_name": "Lakeforge",
  "version": "1.0.0",
  "colors": {
    "primary": "#FF6F00",
    "primary_dark": "#E65100",
    "primary_light": "#FF9800",
    "accent": "#FFA726",
    "background": "#0D1117",
    "surface": "#161B22",
    "border": "#30363D",
    "text_primary": "#E6EDF3",
    "text_secondary": "#8B949E",
    "text_muted": "#6E7681",
    "success": "#3FB950",
    "warning": "#D29922",
    "error": "#F85149",
    "info": "#58A6FF"
  },
  "typography": {
    "font_family_base": "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif",
    "font_family_mono": "'SF Mono', Monaco, 'Cascadia Code', 'Courier New', monospace",
    "font_size_base": "16px",
    "font_size_h1": "2.0em",
    "font_size_h2": "1.5em",
    "font_size_h3": "1.25em",
    "font_size_small": "0.875em",
    "font_size_code": "0.9em",
    "font_weight_normal": "400",
    "font_weight_medium": "500",
    "font_weight_semibold": "600",
    "font_weight_bold": "700",
    "line_height_tight": "1.25",
    "line_height_normal": "1.6",
    "line_height_loose": "1.8"
  },
  "assets": {
    "logo": "/static/lakeforge-logo.svg",
    "favicon": "/static/lakeforge-favicon.png"
  },
  "metadata": {
    "created_at": "2026-01-19T00:00:00Z",
    "author": "Lakeforge Team",
    "description": "Databricks branding for Lakeforge dashboard"
  }
}
```

## Validation

### JSON Schema Validation

Use `brand-config.schema.json` for validation (JSON Schema v7):

```bash
# Python validation (requires jsonschema)
python3 -c "
import json
import jsonschema

with open('src/specify_cli/dashboard/brand-config.json') as f:
    config = json.load(f)

with open('src/specify_cli/dashboard/brand-config.schema.json') as f:
    schema = json.load(f)

jsonschema.validate(config, schema)
print('✓ Valid brand config')
"
```

### Python Tests

Run brand configuration tests:

```bash
pytest tests/test_dashboard/test_branding.py -v
```

**Test coverage**:
- File existence checks
- JSON syntax validation
- Required fields validation
- Hex color format validation
- Project name verification ("Lakeforge", not "Lakeforge")
- Schema validation (if jsonschema installed)
- Databricks color verification
- System font stack validation

## Usage in Dashboard

**WP03 (JavaScript Brand Injection)** implements dynamic branding:

1. **On page load**: JavaScript fetches `/brand-config.json`
2. **Text replacement**: `document.title`, header `<h1>`, welcome message updated to "Lakeforge"
3. **Logo injection**: `<img>` src updated to config `assets.logo`
4. **CSS injection**: Colors injected as CSS custom properties in `:root`

**Example JavaScript** (from WP03):
```javascript
async function loadBrandConfig() {
  try {
    const response = await fetch('/brand-config.json');
    if (response.ok) {
      BRAND_CONFIG = await response.json();
      applyBranding();
    }
  } catch (error) {
    console.error('Failed to load brand config:', error);
  }
}

function applyBranding() {
  if (!BRAND_CONFIG) return;

  // Update text
  document.title = `${BRAND_CONFIG.project_name} Dashboard`;

  // Inject CSS variables
  const root = document.documentElement;
  Object.entries(BRAND_CONFIG.colors).forEach(([key, value]) => {
    root.style.setProperty(`--${key.replace(/_/g, '-')}`, value);
  });
}
```

## Customization

To customize branding:

1. **Edit `brand-config.json`**: Update colors, typography, project name
2. **Validate**: Run `pytest tests/test_dashboard/test_branding.py`
3. **Test**: Start dashboard (`lakeforge dashboard`) and verify changes in browser
4. **WCAG check**: Ensure text-on-background contrast meets 4.5:1 ratio

**Color customization tips**:
- Use [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/) for WCAG AA compliance
- Keep `text_primary` high contrast (light text on dark background for dark themes)
- Maintain brand identity with primary color (e.g., Databricks orange `#FF6F00`)

## Upstream Compatibility

**LAKEFORGE-CUSTOM markers** isolate branding changes:

- `brand-config.json` is a **new file** (upstream won't have it)
- Endpoint route in `router.py` uses `# LAKEFORGE-CUSTOM` markers
- Handler method in `api.py` uses `# LAKEFORGE-CUSTOM` markers

**Merge strategy**:
- Upstream changes to `router.py` or `api.py` typically **won't conflict** (additions at end of file)
- If conflicts occur, preserve LAKEFORGE-CUSTOM sections
- `brand-config.json` will never conflict (doesn't exist upstream)

## Related Work Packages

- **WP01** (this package): Brand configuration foundation
- **WP02**: CSS override layer (`lakeforge-theme.css`)
- **WP03**: JavaScript brand injection (dynamic text replacement, CSS injection)
- **WP04**: Logo assets and visual polish

---

**Last updated**: 2026-01-19
**Feature**: 021-dashboard-databricks-branding
**Status**: WP01 complete (brand-config.json, schema, tests, endpoint, documentation)
