"""Init command implementation for Lakeforge CLI."""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Callable

import httpx
import typer
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from ruamel.yaml import YAML

from lakeforge_cli.cli import StepTracker, select_with_arrows, multi_select_with_arrows
from lakeforge_cli.core import (
    AGENT_TOOL_REQUIREMENTS,
    AI_CHOICES,
    DEFAULT_MISSION_KEY,
    DEFAULT_TEMPLATE_REPO,
    MISSION_CHOICES,
    SCRIPT_TYPE_CHOICES,
    check_tool,
    init_git_repo,
    is_git_repo,
)
from lakeforge_cli.core.git_ops import exclude_from_git_index
from lakeforge_cli.core.vcs import (
    is_git_available,
    VCSBackend,
)
from lakeforge_cli.dashboard import ensure_dashboard_running
from lakeforge_cli.gitignore_manager import GitignoreManager, ProtectionResult
from lakeforge_cli.integrations import ai_dev_kit as adk
from lakeforge_cli.orchestrator.agent_config import (
    AgentConfig,
    AgentSelectionConfig,
    SelectionStrategy,
    save_agent_config,
)
from .init_help import INIT_COMMAND_DOC
from lakeforge_cli.template import (
    GitHubClientError,
    SSL_CONTEXT,
    build_http_client,
    copy_specify_base_from_local,
    copy_specify_base_from_package,
    download_and_extract_template,
    generate_agent_assets,
    get_local_repo_root,
    parse_repo_slug,
    prepare_command_templates,
)

# Templates to override when --package is specified
PACKAGE_OVERRIDE_TEMPLATES = [
    "specify.md",
    "constitution.md",
    "plan.md",
    "tasks.md",
    "implement.md",
    "review.md",
    "accept.md",
]

# Per-package configuration. Each package declares the mission it activates,
# which command templates to override, and (optionally) which ai-dev-kit
# resources are required for that package.
#
# To add a new package, add an entry here. ai_dev_kit.skills_profile must be
# one of: "all", "data-engineer", "ai-ml-engineer", "app-developer".
# Custom skill selections can use ai_dev_kit.skills (list of skill names)
# instead of skills_profile.
PACKAGE_CONFIG: dict[str, dict] = {
    "lakehouse-buildout": {
        "mission": "databricks-lakehouse-buildout",
        "templates_to_override": PACKAGE_OVERRIDE_TEMPLATES,
        "ai_dev_kit": {
            "required": True,
            "skills_profile": "data-engineer",
        },
    },
}

# Backward-compatible map of package name -> mission directory.
# Derived from PACKAGE_CONFIG; existing code reads this dict.
PACKAGE_MAPPING: dict[str, str] = {
    key: cfg["mission"] for key, cfg in PACKAGE_CONFIG.items()
}


def get_package_ai_dev_kit_config(package: str | None) -> dict | None:
    """Return ai-dev-kit config for a package, or None if not required.

    Returns None when:
    - package is None or unknown
    - the package does not require ai-dev-kit
    """
    if not package:
        return None
    cfg = PACKAGE_CONFIG.get(package, {}).get("ai_dev_kit")
    if cfg and cfg.get("required"):
        return cfg
    return None

# Module-level variables to hold injected dependencies
_console: Console | None = None
_show_banner: Callable[[], None] | None = None
_activate_mission: Callable[[Path, str, str, Console], str] | None = None
_ensure_executable_scripts: Callable[[Path, StepTracker | None], None] | None = None


# =============================================================================
# VCS Detection and Configuration
# =============================================================================


class VCSNotFoundError(Exception):
    """Raised when no VCS tools are available."""

    pass


def _is_truthy_env(value: str | None) -> bool:
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def _is_non_interactive_mode(flag: bool) -> bool:
    if flag:
        return True
    if _is_truthy_env(os.environ.get("LAKEFORGE_NON_INTERACTIVE")):
        return True
    return not sys.stdin.isatty()


def _resolve_non_interactive_strategy(
    selected_agents: list[str],
    agent_strategy: str | None,
    preferred_implementer: str | None,
    preferred_reviewer: str | None,
) -> tuple[str, str | None, str | None]:
    if not selected_agents:
        raise ValueError("At least one agent must be selected")

    resolved_strategy = (agent_strategy or "preferred").strip().lower()
    if resolved_strategy not in ("preferred", "random"):
        raise ValueError("Invalid agent strategy. Choose from: preferred, random")

    if resolved_strategy == "random":
        if preferred_implementer or preferred_reviewer:
            raise ValueError("--preferred-implementer/--preferred-reviewer require --agent-strategy preferred")
        return resolved_strategy, None, None

    if preferred_implementer and preferred_implementer not in selected_agents:
        raise ValueError("Preferred implementer must be one of the selected agents")
    if preferred_reviewer and preferred_reviewer not in selected_agents:
        raise ValueError("Preferred reviewer must be one of the selected agents")

    if not preferred_implementer:
        preferred_implementer = selected_agents[0]
    if not preferred_reviewer:
        if len(selected_agents) > 1:
            preferred_reviewer = next(
                agent for agent in selected_agents if agent != preferred_implementer
            )
        else:
            preferred_reviewer = preferred_implementer

    return resolved_strategy, preferred_implementer, preferred_reviewer


def _detect_default_vcs() -> VCSBackend:
    """Detect the default VCS based on tool availability.

    Returns VCSBackend.GIT if git is available.
    Raises VCSNotFoundError if git is not available.

    Note: jj support removed due to sparse checkout incompatibility.
    """
    if is_git_available():
        return VCSBackend.GIT
    else:
        raise VCSNotFoundError("git is not available. Please install git.")


def _display_vcs_info(detected_vcs: VCSBackend, console: Console) -> None:
    """Display informational message about VCS selection.

    Args:
        detected_vcs: The detected/selected VCS backend (always GIT)
        console: Rich console for output
    """
    console.print("[green]✓ git detected[/green] - will be used for version control")


def _save_vcs_config(config_path: Path, detected_vcs: VCSBackend) -> None:
    """Save VCS preference to config.yaml.

    Args:
        config_path: Path to .lakeforge directory
        detected_vcs: The detected/selected VCS backend (always GIT)
    """
    config_file = config_path / "config.yaml"

    yaml = YAML()
    yaml.preserve_quotes = True

    # Load existing config or create new
    if config_file.exists():
        with open(config_file, "r") as f:
            config = yaml.load(f) or {}
    else:
        config = {}
        config_path.mkdir(parents=True, exist_ok=True)

    # Add/update vcs section (git only)
    config["vcs"] = {
        "type": "git",
    }

    # Write back
    with open(config_file, "w") as f:
        yaml.dump(config, f)


def _install_git_hooks(project_path: Path, templates_root: Path | None = None, tracker: StepTracker | None = None) -> None:
    """Install git hooks from templates to .git/hooks directory.

    Args:
        project_path: Path to the project root
        templates_root: Path to the templates directory (if available)
        tracker: Optional progress tracker
    """
    git_hooks_dir = project_path / ".git" / "hooks"
    # Use templates_root if available, otherwise fall back to user project (for backwards compat)
    if templates_root:
        template_hooks_dir = templates_root / "git-hooks"
    else:
        template_hooks_dir = project_path / ".lakeforge" / "templates" / "git-hooks"

    if not git_hooks_dir.exists():
        if tracker:
            tracker.skip("git-hooks", ".git/hooks directory not found")
        return

    if not template_hooks_dir.exists():
        if tracker:
            tracker.skip("git-hooks", "no hook templates found")
        return

    installed_count = 0
    for hook_template in template_hooks_dir.iterdir():
        if hook_template.is_file() and not hook_template.name.startswith('.'):
            hook_dest = git_hooks_dir / hook_template.name
            shutil.copy2(hook_template, hook_dest)
            # Make executable on POSIX systems
            if os.name != "nt":
                hook_dest.chmod(0o755)
            installed_count += 1

    if tracker:
        if installed_count > 0:
            tracker.complete("git-hooks", f"{installed_count} hook(s) installed")
        else:
            tracker.skip("git-hooks", "no hooks to install")


def init(
    project_name: str = typer.Argument(None, help="Name for your new project directory (optional if using --here, or use '.' for current directory)"),
    ai_assistant: str = typer.Option(None, "--ai", help="Comma-separated AI assistants (claude,codex,gemini,...)", rich_help_panel="Selection"),
    script_type: str = typer.Option(None, "--script", help="Script type to use: sh or ps", rich_help_panel="Selection"),
    agent_strategy: str = typer.Option(None, "--agent-strategy", help="Agent selection strategy: preferred or random", rich_help_panel="Selection"),
    preferred_implementer: str = typer.Option(None, "--preferred-implementer", help="Preferred agent for implementation", rich_help_panel="Selection"),
    preferred_reviewer: str = typer.Option(None, "--preferred-reviewer", help="Preferred agent for review", rich_help_panel="Selection"),
    mission_key: str = typer.Option(None, "--mission", hidden=True, help="[DEPRECATED] Mission selection moved to /specify"),
    ignore_agent_tools: bool = typer.Option(False, "--ignore-agent-tools", help="Skip checks for AI agent tools like Claude Code"),
    no_git: bool = typer.Option(False, "--no-git", help="Skip git repository initialization"),
    here: bool = typer.Option(False, "--here", help="Initialize project in the current directory instead of creating a new one"),
    force: bool = typer.Option(False, "--force", help="Force merge/overwrite when using --here (skip confirmation)"),
    non_interactive: bool = typer.Option(False, "--non-interactive", "--yes", help="Run without interactive prompts (suitable for CI/CD)"),
    skip_tls: bool = typer.Option(False, "--skip-tls", help="Skip SSL/TLS verification (not recommended)"),
    debug: bool = typer.Option(False, "--debug", help="Show verbose diagnostic output for network and extraction failures"),
    github_token: str = typer.Option(None, "--github-token", help="GitHub token to use for API requests (or set GH_TOKEN or GITHUB_TOKEN environment variable)"),
    template_root: str = typer.Option(None, "--template-root", help="Override default template location (useful for development mode)"),
    package: str = typer.Option(None, "--package", help="Package: deploys mission-specific specify and constitution commands (e.g., lakehouse-buildout)"),
    docs_source: str = typer.Option(None, "--docs-source", help="Documentation access method for packages: webfetch or mcp", rich_help_panel="Selection"),
):
    """Initialize a new Lakeforge project."""
    # Use the injected dependencies
    assert _console is not None
    assert _show_banner is not None
    assert _activate_mission is not None
    assert _ensure_executable_scripts is not None

    _show_banner()
    non_interactive = _is_non_interactive_mode(non_interactive)

    # Handle '.' as shorthand for current directory (equivalent to --here)
    if project_name == ".":
        here = True
        project_name = None  # Clear project_name to use existing validation logic

    if here and project_name:
        _console.print("[red]Error:[/red] Cannot specify both project name and --here flag")
        raise typer.Exit(1)

    if not here and not project_name:
        _console.print("[red]Error:[/red] Must specify either a project name, use '.' for current directory, or use --here flag")
        raise typer.Exit(1)

    if here:
        try:
            project_path = Path.cwd()
            project_name = project_path.name
        except (OSError, FileNotFoundError) as e:
            _console.print("[red]Error:[/red] Cannot access current directory")
            _console.print(f"[dim]{e}[/dim]")
            _console.print("[yellow]Hint:[/yellow] Your current directory may have been deleted or is no longer accessible")
            raise typer.Exit(1)

        existing_items = list(project_path.iterdir())
        if existing_items:
            _console.print(f"[yellow]Warning:[/yellow] Current directory is not empty ({len(existing_items)} items)")
            _console.print("[yellow]Template files will be merged with existing content and may overwrite existing files[/yellow]")
            if force:
                _console.print("[cyan]--force supplied: skipping confirmation and proceeding with merge[/cyan]")
            else:
                if non_interactive:
                    _console.print("[red]Error:[/red] Non-interactive mode requires --force when using --here in a non-empty directory")
                    raise typer.Exit(1)
                response = typer.confirm("Do you want to continue?")
                if not response:
                    _console.print("[yellow]Operation cancelled[/yellow]")
                    raise typer.Exit(0)
    else:
        project_path = Path(project_name).resolve()
        if project_path.exists():
            error_panel = Panel(
                f"Directory '[cyan]{project_name}[/cyan]' already exists\n"
                "Please choose a different project name or remove the existing directory.",
                title="[red]Directory Conflict[/red]",
                border_style="red",
                padding=(1, 2)
            )
            _console.print()
            _console.print(error_panel)
            raise typer.Exit(1)

    current_dir = Path.cwd()

    setup_lines = [
        "[cyan]Specify Project Setup[/cyan]",
        "",
        f"{'Project':<15} [green]{project_path.name}[/green]",
        f"{'Working Path':<15} [dim]{current_dir}[/dim]",
    ]

    # Add target path only if different from working dir
    if not here:
        setup_lines.append(f"{'Target Path':<15} [dim]{project_path}[/dim]")

    _console.print(Panel("\n".join(setup_lines), border_style="cyan", padding=(1, 2)))

    # Check git only if we might need it (not --no-git)
    # Only set to True if the user wants it and the tool is available
    should_init_git = False
    if not no_git:
        should_init_git = check_tool("git", "https://git-scm.com/downloads")
        if not should_init_git:
            _console.print("[yellow]Git not found - will skip repository initialization[/yellow]")

    # Detect VCS (git only, jj support removed)
    selected_vcs: VCSBackend | None = None
    try:
        selected_vcs = _detect_default_vcs()
        _console.print()
        _display_vcs_info(selected_vcs, _console)
        _console.print()
    except VCSNotFoundError:
        # git not available - not an error, just informational
        selected_vcs = None
        _console.print("[yellow]ℹ git not detected[/yellow] - install git for version control")

    if ai_assistant:
        raw_agents = [part.strip().lower() for part in ai_assistant.replace(";", ",").split(",") if part.strip()]
        if not raw_agents:
            _console.print("[red]Error:[/red] --ai flag did not contain any valid agent identifiers")
            raise typer.Exit(1)
        selected_agents: list[str] = []
        seen_agents: set[str] = set()
        invalid_agents: list[str] = []
        for key in raw_agents:
            if key not in AI_CHOICES:
                invalid_agents.append(key)
                continue
            if key not in seen_agents:
                selected_agents.append(key)
                seen_agents.add(key)
        if invalid_agents:
            _console.print(
                f"[red]Error:[/red] Invalid AI assistant(s): {', '.join(invalid_agents)}. "
                f"Choose from: {', '.join(AI_CHOICES.keys())}"
            )
            raise typer.Exit(1)
    else:
        if non_interactive:
            _console.print("[red]Error:[/red] --ai is required in non-interactive mode")
            raise typer.Exit(1)
        selected_agents = multi_select_with_arrows(
            AI_CHOICES,
            "Choose your AI assistant(s):",
            default_keys=["copilot"],
        )

    if not selected_agents:
        _console.print("[red]Error:[/red] No AI assistants selected")
        raise typer.Exit(1)

    # Check agent tools unless ignored
    if not ignore_agent_tools:
        missing_agents: list[tuple[str, str, str]] = []  # (agent key, display, url)
        for agent_key in selected_agents:
            requirement = AGENT_TOOL_REQUIREMENTS.get(agent_key)
            if not requirement:
                continue
            tool_name, url = requirement
            if not check_tool(tool_name, url, agent_name=agent_key):
                missing_agents.append((agent_key, AI_CHOICES[agent_key], url))

        if missing_agents:
            lines = []
            for agent_key, display_name, url in missing_agents:
                lines.append(f"[cyan]{display_name}[/cyan] ({agent_key}) → install: [cyan]{url}[/cyan]")
            lines.append("")
            lines.append("These tools are optional. You can install them later to enable additional features.")
            warning_panel = Panel(
                "\n".join(lines),
                title="[yellow]Optional Agent Tool(s) Not Found[/yellow]",
                border_style="yellow",
                padding=(1, 2),
            )
            _console.print()
            _console.print(warning_panel)
            # Continue with init instead of blocking

    # ==========================================================================
    # Agent Selection Strategy (for orchestrator)
    # ==========================================================================
    _console.print()
    _console.print("[cyan]Agent Selection Strategy[/cyan]")
    _console.print("[dim]This determines how agents are chosen for implementation and review tasks.[/dim]")
    _console.print()

    strategy_choices = {
        "preferred": "Preferred Agents - You choose which agent implements and which reviews",
        "random": "Random - Randomly select from available agents each time",
    }
    selected_strategy: str
    if agent_strategy:
        selected_strategy = agent_strategy.strip().lower()
        if selected_strategy not in strategy_choices:
            _console.print("[red]Error:[/red] Invalid --agent-strategy. Choose from: preferred, random")
            raise typer.Exit(1)
    elif preferred_implementer or preferred_reviewer:
        selected_strategy = "preferred"
    elif non_interactive:
        selected_strategy = "preferred"
    else:
        selected_strategy = select_with_arrows(
            strategy_choices,
            "How should agents be selected for tasks?",
            default_key="preferred",
        )

    preferred_implementer_value: str | None = preferred_implementer
    preferred_reviewer_value: str | None = preferred_reviewer
    preferred_implementer: str | None = None
    preferred_reviewer: str | None = None

    if selected_strategy == "preferred":
        # Ask for preferred implementer
        agent_display_map = {key: AI_CHOICES[key] for key in selected_agents}

        _console.print()
        if preferred_implementer_value:
            if preferred_implementer_value not in selected_agents:
                _console.print("[red]Error:[/red] --preferred-implementer must be one of the selected agents")
                raise typer.Exit(1)
            preferred_implementer = preferred_implementer_value
        elif non_interactive:
            preferred_implementer = selected_agents[0]
        else:
            preferred_implementer = select_with_arrows(
                agent_display_map,
                "Which agent should be the preferred IMPLEMENTER?",
                default_key=selected_agents[0],
            )

        # Ask for preferred reviewer (prefer different from implementer)
        _console.print()
        if len(selected_agents) > 1:
            # Default to a different agent for review
            default_reviewer = next((a for a in selected_agents if a != preferred_implementer), selected_agents[0])
            if preferred_reviewer_value:
                if preferred_reviewer_value not in selected_agents:
                    _console.print("[red]Error:[/red] --preferred-reviewer must be one of the selected agents")
                    raise typer.Exit(1)
                preferred_reviewer = preferred_reviewer_value
            elif non_interactive:
                preferred_reviewer = default_reviewer
            else:
                preferred_reviewer = select_with_arrows(
                    agent_display_map,
                    "Which agent should be the preferred REVIEWER?",
                    default_key=default_reviewer,
                )
            if preferred_reviewer == preferred_implementer and len(selected_agents) > 1:
                _console.print("[yellow]Note:[/yellow] Same agent for implementation and review (cross-review disabled)")
        else:
            # Only one agent - same for both
            preferred_reviewer = preferred_implementer
            _console.print(f"[dim]Single agent mode: {AI_CHOICES[preferred_implementer]} will do both implementation and review[/dim]")
    else:
        if preferred_implementer_value or preferred_reviewer_value:
            _console.print("[red]Error:[/red] --preferred-implementer/--preferred-reviewer require --agent-strategy preferred")
            raise typer.Exit(1)

    if non_interactive:
        try:
            resolved_strategy, resolved_impl, resolved_rev = _resolve_non_interactive_strategy(
                selected_agents,
                selected_strategy,
                preferred_implementer_value,
                preferred_reviewer_value,
            )
        except ValueError as exc:
            _console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(1)
        selected_strategy = resolved_strategy
        if selected_strategy == "preferred":
            preferred_implementer = resolved_impl
            preferred_reviewer = resolved_rev

    # Build agent config to save later
    agent_config = AgentConfig(
        available=selected_agents,
        selection=AgentSelectionConfig(
            strategy=SelectionStrategy(selected_strategy),
            preferred_implementer=preferred_implementer,
            preferred_reviewer=preferred_reviewer,
        ),
    )

    # Determine script type (explicit or auto-detect)
    if script_type:
        if script_type not in SCRIPT_TYPE_CHOICES:
            _console.print(f"[red]Error:[/red] Invalid script type '{script_type}'. Choose from: {', '.join(SCRIPT_TYPE_CHOICES.keys())}")
            raise typer.Exit(1)
        selected_script = script_type
    else:
        # Auto-detect based on platform
        selected_script = "ps" if os.name == "nt" else "sh"
        _console.print(f"[dim]Auto-detected script type:[/dim] [cyan]{SCRIPT_TYPE_CHOICES[selected_script]}[/cyan]")

    # Docs source selection for Databricks packages
    selected_docs_source = "webfetch"
    if package and package in PACKAGE_MAPPING:
        if docs_source:
            selected_docs_source = docs_source.strip().lower()
            if selected_docs_source not in ("webfetch", "mcp"):
                _console.print("[red]Error:[/red] Invalid --docs-source. Choose from: webfetch, mcp")
                raise typer.Exit(1)
        elif non_interactive:
            selected_docs_source = "webfetch"
        else:
            _console.print()
            _console.print("[cyan]Databricks Documentation Access[/cyan]")
            _console.print("[dim]Choose how AI agents should access Databricks documentation during workflows.[/dim]")
            _console.print()
            docs_source_choices = {
                "webfetch": "WebFetch (default) - Agents fetch docs.databricks.com/llms.txt at runtime",
                "mcp": "Databricks Docs MCP - Agents use your configured MCP server for doc lookups (see README.md)",
            }
            selected_docs_source = select_with_arrows(
                docs_source_choices,
                "How should Databricks documentation be accessed?",
                default_key="webfetch",
            )

    # Mission selection deprecated - missions are now per-feature
    if mission_key:
        _console.print("[yellow]Warning:[/yellow] The --mission flag is deprecated. Missions are now selected per-feature during /specify")
        _console.print("[dim]Ignoring --mission flag and continuing with initialization...[/dim]")
        _console.print()

    # No longer select a project-level mission - just use software-dev for initial setup
    selected_mission = DEFAULT_MISSION_KEY
    mission_display = MISSION_CHOICES.get(selected_mission, "Software Development")

    template_mode = "package"
    local_repo = get_local_repo_root(override_path=template_root)
    if local_repo is not None:
        template_mode = "local"
        if debug:
            _console.print(f"[cyan]Using local templates from[/cyan] {local_repo}")

    repo_owner = repo_name = None
    remote_slug_env = os.environ.get("LAKEFORGE_TEMPLATE_REPO")
    if remote_slug_env:
        try:
            repo_owner, repo_name = parse_repo_slug(remote_slug_env)
        except ValueError as exc:
            _console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(1)
        template_mode = "remote"
        if debug:
            _console.print(f"[cyan]Using remote templates from[/cyan] {repo_owner}/{repo_name}")
    elif template_mode == "package" and debug:
        _console.print("[cyan]Using templates bundled with lakeforge_cli package[/cyan]")

    ai_display = ", ".join(AI_CHOICES[key] for key in selected_agents)
    _console.print(f"[cyan]Selected AI assistant(s):[/cyan] {ai_display}")
    _console.print(f"[cyan]Selected script type:[/cyan] {selected_script}")
    _console.print(f"[cyan]Selected mission:[/cyan] {mission_display}")

    # Download and set up project
    # New tree-based progress (no emojis); include earlier substeps
    tracker = StepTracker("Initialize Specify Project")
    # Flag to allow suppressing legacy headings
    sys._specify_tracker_active = True
    # Pre steps recorded as completed before live rendering
    tracker.add("precheck", "Check required tools")
    tracker.complete("precheck", "ok")
    tracker.add("ai-select", "Select AI assistant(s)")
    tracker.complete("ai-select", ai_display)
    tracker.add("script-select", "Select script type")
    tracker.complete("script-select", selected_script)
    tracker.add("mission-select", "Select mission")
    tracker.complete("mission-select", mission_display)
    tracker.add("mission-activate", "Activate mission")
    for agent_key in selected_agents:
        label = AI_CHOICES[agent_key]
        tracker.add(f"{agent_key}-fetch", f"{label}: fetch latest release")
        tracker.add(f"{agent_key}-download", f"{label}: download template")
        tracker.add(f"{agent_key}-extract", f"{label}: extract template")
        tracker.add(f"{agent_key}-zip-list", f"{label}: archive contents")
        tracker.add(f"{agent_key}-extracted-summary", f"{label}: extraction summary")
        tracker.add(f"{agent_key}-cleanup", f"{label}: cleanup")
    for key, label in [
        ("chmod", "Ensure scripts executable"),
        ("git", "Initialize git repository"),
        ("final", "Finalize"),
    ]:
        tracker.add(key, label)

    if template_mode in ("local", "package") and not here and not project_path.exists():
        project_path.mkdir(parents=True)

    command_templates_dir: Path | None = None
    render_templates_dir: Path | None = None
    templates_root: Path | None = None  # Track template source for later use
    base_prepared = False
    if template_mode == "remote" and (repo_owner is None or repo_name is None):
        repo_owner, repo_name = parse_repo_slug(DEFAULT_TEMPLATE_REPO)

    with Live(tracker.render(), console=_console, refresh_per_second=8, transient=True) as live:
        tracker.attach_refresh(lambda: live.update(tracker.render()))
        try:
            # Create a httpx client with verify based on skip_tls
            local_client = build_http_client(skip_tls=skip_tls)

            for index, agent_key in enumerate(selected_agents):
                if template_mode in ("local", "package"):
                    source_detail = "local checkout" if template_mode == "local" else "packaged data"
                    tracker.start(f"{agent_key}-fetch")
                    tracker.complete(f"{agent_key}-fetch", source_detail)
                    tracker.start(f"{agent_key}-download")
                    tracker.complete(f"{agent_key}-download", "local files")
                    tracker.start(f"{agent_key}-extract")
                    try:
                        if not base_prepared:
                            if template_mode == "local":
                                command_templates_dir = copy_specify_base_from_local(local_repo, project_path, selected_script)
                            else:
                                command_templates_dir = copy_specify_base_from_package(project_path, selected_script)
                            base_prepared = True
                            # Track templates root for later use (AGENTS.md, .claudeignore, git-hooks)
                            if command_templates_dir:
                                templates_root = command_templates_dir.parent
                        if command_templates_dir is None:
                            raise RuntimeError("Command templates directory was not prepared")
                        if render_templates_dir is None:
                            # Determine which mission templates to use for override
                            override_mission = None
                            override_templates = None

                            if package:
                                if package not in PACKAGE_MAPPING:
                                    _console.print(f"[red]Error:[/red] Unknown package: {package}")
                                    _console.print(f"[yellow]Available packages:[/yellow] {', '.join(PACKAGE_MAPPING.keys())}")
                                    raise typer.Exit(1)
                                override_mission = PACKAGE_MAPPING[package]
                                override_templates = PACKAGE_OVERRIDE_TEMPLATES

                            mission_templates_dir = None
                            if override_mission:
                                # Use ps-package mission for selective override
                                mission_templates_dir = (
                                    project_path
                                    / ".lakeforge"
                                    / "missions"
                                    / override_mission
                                    / "command-templates"
                                )
                            else:
                                # Default behavior: use selected_mission (software-dev)
                                mission_templates_dir = (
                                    project_path
                                    / ".lakeforge"
                                    / "missions"
                                    / selected_mission
                                    / "command-templates"
                                )

                            render_templates_dir = prepare_command_templates(
                                command_templates_dir,
                                mission_templates_dir,
                                override_templates=override_templates,
                            )
                        generate_agent_assets(render_templates_dir, project_path, agent_key, selected_script, docs_source=selected_docs_source)
                    except Exception as exc:
                        tracker.error(f"{agent_key}-extract", str(exc))
                        raise
                    else:
                        tracker.complete(f"{agent_key}-extract", "commands generated")
                        tracker.start(f"{agent_key}-zip-list")
                        tracker.complete(f"{agent_key}-zip-list", "templates ready")
                        tracker.start(f"{agent_key}-extracted-summary")
                        tracker.complete(f"{agent_key}-extracted-summary", "commands ready")
                        tracker.start(f"{agent_key}-cleanup")
                        tracker.complete(f"{agent_key}-cleanup", "done")
                else:
                    is_current_dir_flag = here if index == 0 else True
                    allow_existing_flag = index > 0
                    download_and_extract_template(
                        project_path,
                        agent_key,
                        selected_script,
                        is_current_dir_flag,
                        verbose=False,
                        tracker=tracker,
                        tracker_prefix=agent_key,
                        allow_existing=allow_existing_flag,
                        client=local_client,
                        debug=debug,
                        github_token=github_token,
                        repo_owner=repo_owner,
                        repo_name=repo_name,
                    )

            tracker.start("mission-activate")
            try:
                mission_status = _activate_mission(project_path, selected_mission, mission_display, _console)
            except Exception as exc:
                tracker.error("mission-activate", str(exc))
                raise
            else:
                tracker.complete("mission-activate", mission_status)

            # Ensure scripts are executable (POSIX)
            _ensure_executable_scripts(project_path, tracker=tracker)

            # Git step - must happen BEFORE hook installation
            if not no_git:
                tracker.start("git")
                if is_git_repo(project_path):
                    tracker.complete("git", "existing repo detected")
                elif should_init_git:
                    if init_git_repo(project_path, quiet=True):
                        tracker.complete("git", "initialized")
                    else:
                        tracker.error("git", "init failed")
                else:
                    tracker.skip("git", "git not available")
            else:
                tracker.skip("git", "--no-git flag")

            # Exclude .worktrees/ from git index (defensive protection)
            if not no_git and is_git_repo(project_path):
                exclude_from_git_index(project_path, [".worktrees/"])

            # Install git hooks AFTER git is initialized
            if not no_git and is_git_repo(project_path):
                tracker.add("git-hooks", "Install git hooks")
                tracker.start("git-hooks")
                _install_git_hooks(project_path, templates_root=templates_root, tracker=tracker)

            tracker.complete("final", "project ready")
        except Exception as e:
            tracker.error("final", str(e))
            _console.print(Panel(f"Initialization failed: {e}", title="Failure", border_style="red"))
            if debug:
                _env_pairs = [
                    ("Python", sys.version.split()[0]),
                    ("Platform", sys.platform),
                    ("CWD", str(Path.cwd())),
                ]
                _label_width = max(len(k) for k, _ in _env_pairs)
                env_lines = [f"{k.ljust(_label_width)} → [bright_black]{v}[/bright_black]" for k, v in _env_pairs]
                _console.print(Panel("\n".join(env_lines), title="Debug Environment", border_style="magenta"))
            if not here and project_path.exists():
                shutil.rmtree(project_path)
            raise typer.Exit(1)
        finally:
            # Force final render
            pass

    # Final static tree (ensures finished state visible after Live context ends)
    _console.print(tracker.render())
    _console.print("\n[bold green]Project ready.[/bold green]")

    # Agent folder security notice
    agent_folder_map = {
        "claude": ".claude/",
        "gemini": ".gemini/",
        "cursor": ".cursor/",
        "qwen": ".qwen/",
        "opencode": ".opencode/",
        "codex": ".codex/",
        "windsurf": ".windsurf/",
        "kilocode": ".kilocode/",
        "auggie": ".augment/",
        "copilot": ".github/",
        "roo": ".roo/",
        "q": ".amazonq/"
    }

    notice_entries = []
    for agent_key in selected_agents:
        folder = agent_folder_map.get(agent_key)
        if folder:
            notice_entries.append((AI_CHOICES[agent_key], folder))

    if notice_entries:
        body_lines = [
            "Some agents may store credentials, auth tokens, or other identifying and private artifacts in the agent folder within your project.",
            "Consider adding the following folders (or subsets) to [cyan].gitignore[/cyan]:",
            "",
        ]
        body_lines.extend(f"- {display}: [cyan]{folder}[/cyan]" for display, folder in notice_entries)
        security_notice = Panel(
            "\n".join(body_lines),
            title="[yellow]Agent Folder Security[/yellow]",
            border_style="yellow",
            padding=(1, 2),
        )
        _console.print()
        _console.print(security_notice)

    # Boxed "Next steps" section
    steps_lines = []
    step_num = 1
    if not here:
        steps_lines.append(f"{step_num}. Go to the project folder: [cyan]cd {project_name}[/cyan]")
    else:
        steps_lines.append(f"{step_num}. You're already in the project directory!")
    step_num += 1

    steps_lines.append(f"{step_num}. Available missions: [cyan]software-dev[/cyan], [cyan]research[/cyan] (selected per-feature during [cyan]/specify[/cyan])")
    step_num += 1

    steps_lines.append(f"{step_num}. Start using slash commands with your AI agent (in workflow order):")
    step_num += 1

    steps_lines.append("   - [cyan]/dashboard[/] - Open the real-time kanban dashboard")
    steps_lines.append("   - [cyan]/constitution[/] - Establish project principles")
    steps_lines.append("   - [cyan]/specify[/] - Create baseline specification")
    steps_lines.append("   - [cyan]/plan[/] - Create implementation plan")
    steps_lines.append("   - [cyan]/research[/] - Run mission-specific Phase 0 research scaffolding")
    steps_lines.append("   - [cyan]/tasks[/] - Generate tasks and kanban-ready prompt files")
    steps_lines.append("   - [cyan]/implement[/] - Execute implementation from /tasks/doing/")
    steps_lines.append("   - [cyan]/review[/] - Review prompts and move them to /tasks/done/")
    steps_lines.append("   - [cyan]/accept[/] - Run acceptance checks and verify feature complete")
    steps_lines.append("   - [cyan]/merge[/] - Merge feature into main and cleanup worktree")

    steps_panel = Panel("\n".join(steps_lines), title="Next Steps", border_style="cyan", padding=(1,2))
    _console.print()
    _console.print(steps_panel)

    enhancement_lines = [
        "Optional commands that you can use for your specs [bright_black](improve quality & confidence)[/bright_black]",
        "",
        f"○ [cyan]/clarify[/] [bright_black](optional)[/bright_black] - Ask structured questions to de-risk ambiguous areas before planning (run before [cyan]/plan[/] if used)",
        f"○ [cyan]/analyze[/] [bright_black](optional)[/bright_black] - Cross-artifact consistency & alignment report (after [cyan]/tasks[/], before [cyan]/implement[/])",
        f"○ [cyan]/checklist[/] [bright_black](optional)[/bright_black] - Generate quality checklists to validate requirements completeness, clarity, and consistency (after [cyan]/plan[/])"
    ]
    enhancements_panel = Panel("\n".join(enhancement_lines), title="Enhancement Commands", border_style="cyan", padding=(1,2))
    _console.print()
    _console.print(enhancements_panel)

    # Start or reconnect to the dashboard server as a detached background process
    _console.print()
    try:
        dashboard_url, port, started = ensure_dashboard_running(project_path)

        title = "[bold green]Lakeforge Dashboard Started[/bold green]" if started else "[bold green]Lakeforge Dashboard Ready[/bold green]"
        status_line = (
            "[dim]The dashboard is running in the background and will continue even after\n"
            "this command exits. It will automatically update as you work.[/dim]"
            if started
            else "[dim]An existing dashboard instance is running and ready.[/dim]"
        )

        dashboard_panel = Panel(
            f"[bold cyan]Dashboard URL:[/bold cyan] {dashboard_url}\n"
            f"[bold cyan]Port:[/bold cyan] {port}\n\n"
            f"{status_line}\n\n"
            f"[yellow]Tip:[/yellow] Run [cyan]/dashboard[/cyan] or [cyan]lakeforge dashboard[/cyan] to open it in your browser",
            title=title,
            border_style="green",
            padding=(1, 2)
        )
        _console.print(dashboard_panel)
        _console.print()
    except Exception as e:
        _console.print(f"[yellow]Warning: Could not start dashboard: {e}[/yellow]")
        _console.print("[dim]Continuing without dashboard...[/dim]")

    # Protect ALL agent directories in .gitignore
    manager = GitignoreManager(project_path)
    result = manager.protect_all_agents()  # Note: ALL agents, not just selected

    # Display results to user
    if result.modified:
        _console.print("[cyan]Updated .gitignore to exclude AI agent directories:[/cyan]")
        for entry in result.entries_added:
            _console.print(f"  • {entry}")
        if result.entries_skipped:
            _console.print(f"  ({len(result.entries_skipped)} already protected)")
    elif result.entries_skipped:
        _console.print(f"[dim]All {len(result.entries_skipped)} agent directories already in .gitignore[/dim]")

    # Show warnings (especially for .github/)
    for warning in result.warnings:
        _console.print(f"[yellow]⚠️  {warning}[/yellow]")

    # Show errors if any
    for error in result.errors:
        _console.print(f"[red]❌ {error}[/red]")

    # Copy AGENTS.md from template source (not user project)
    if templates_root:
        agents_target = project_path / ".lakeforge" / "AGENTS.md"
        agents_template = templates_root / "AGENTS.md"
        if not agents_target.exists() and agents_template.exists():
            shutil.copy2(agents_template, agents_target)

        # Generate .claudeignore from template source
        claudeignore_template = templates_root / "claudeignore-template"
        claudeignore_dest = project_path / ".claudeignore"
        if claudeignore_template.exists() and not claudeignore_dest.exists():
            shutil.copy2(claudeignore_template, claudeignore_dest)
            _console.print("[dim]Created .claudeignore to optimize AI assistant scanning[/dim]")

    # Create project metadata for upgrade tracking
    try:
        from datetime import datetime
        import platform as plat
        import sys as system
        from lakeforge_cli import __version__
        from lakeforge_cli.upgrade.metadata import ProjectMetadata

        metadata = ProjectMetadata(
            version=__version__,
            initialized_at=datetime.now(),
            python_version=plat.python_version(),
            platform=system.platform,
            platform_version=plat.platform(),
        )
        metadata.save(project_path / ".lakeforge")
    except Exception as e:
        # Don't fail init if metadata creation fails
        _console.print(f"[dim]Note: Could not create project metadata: {e}[/dim]")

    # Save VCS preference to config.yaml
    if selected_vcs:
        try:
            _save_vcs_config(project_path / ".lakeforge", selected_vcs)
        except Exception as e:
            # Don't fail init if VCS config creation fails
            _console.print(f"[dim]Note: Could not save VCS config: {e}[/dim]")

    # Save agent configuration to config.yaml
    try:
        save_agent_config(project_path, agent_config)
        _console.print(f"[dim]Saved agent configuration ({selected_strategy} strategy)[/dim]")
    except Exception as e:
        # Don't fail init if agent config creation fails
        _console.print(f"[dim]Note: Could not save agent config: {e}[/dim]")

    # Save package to config.yaml if specified
    if package:
        try:
            config_file = project_path / ".lakeforge" / "config.yaml"
            yaml = YAML()
            yaml.preserve_quotes = True

            if config_file.exists():
                with open(config_file) as f:
                    config = yaml.load(f) or {}
            else:
                config = {}

            config["package"] = package
            config["package_mission"] = PACKAGE_MAPPING[package]
            config["docs_source"] = selected_docs_source

            with open(config_file, "w") as f:
                yaml.dump(config, f)
            _console.print(f"[dim]Saved package configuration: {package}[/dim]")
        except Exception as e:
            # Don't fail init if package config creation fails
            _console.print(f"[dim]Note: Could not save package config: {e}[/dim]")

    # ai-dev-kit installation for packages that require it.
    # Hard-fails init if installation fails — packages that declare ai-dev-kit
    # as required cannot function without it (skills + MCP server are needed
    # by their command templates).
    ai_dev_kit_cfg = get_package_ai_dev_kit_config(package)
    if ai_dev_kit_cfg:
        skills_profile = ai_dev_kit_cfg.get("skills_profile", "all")
        _console.print()
        _console.print(
            f"[cyan]Installing ai-dev-kit (required by '{package}' package)[/cyan]"
        )

        adk_tracker = StepTracker(f"Install ai-dev-kit ({skills_profile} profile)")
        for _key, _label in [
            ("adk-prereqs", "Check prerequisites (git, uv, bash)"),
            ("adk-agents", "Validate ai-dev-kit-supported agents"),
            ("adk-version", "Resolve ai-dev-kit version"),
            ("adk-download", "Download installer"),
            ("adk-install", "Run install.sh (first-time can take minutes)"),
            ("adk-verify", "Verify installation"),
            ("adk-skill-contract", "Validate command-template skill contract"),
            ("adk-metadata", "Save metadata to .lakeforge/config.yaml"),
        ]:
            adk_tracker.add(_key, _label)

        report: dict[str, dict] = {}
        installed_skills: set[str] = set()
        with Live(
            adk_tracker.render(),
            console=_console,
            refresh_per_second=8,
            transient=True,
        ) as adk_live:
            adk_tracker.attach_refresh(
                lambda: adk_live.update(adk_tracker.render())
            )
            try:
                adk_tracker.start("adk-prereqs")
                adk.check_prerequisites()
                adk_tracker.complete("adk-prereqs", "ok")

                adk_tracker.start("adk-agents")
                supported_agents = adk.validate_agents_supported(selected_agents)
                skipped = sorted(set(selected_agents) - set(supported_agents))
                agents_detail = ",".join(supported_agents)
                if skipped:
                    agents_detail += f"; skipped: {','.join(skipped)}"
                adk_tracker.complete("adk-agents", agents_detail)

                adk_tracker.start("adk-version")
                ai_dev_kit_version = adk.resolve_version(project_path)
                adk_tracker.complete("adk-version", ai_dev_kit_version)

                with tempfile.TemporaryDirectory() as tmp_dir:
                    adk_tracker.start("adk-download")
                    installer = adk.download_installer(
                        ai_dev_kit_version, Path(tmp_dir)
                    )
                    adk_tracker.complete(
                        "adk-download", f"{installer.stat().st_size} bytes"
                    )

                    adk_tracker.start("adk-install")
                    adk.run_installer(
                        installer,
                        agents=supported_agents,
                        skills_profile=skills_profile,
                        version=ai_dev_kit_version,
                        project_path=project_path,
                    )
                    adk_tracker.complete("adk-install", "ok")

                adk_tracker.start("adk-verify")
                report = adk.verify_installation(project_path, supported_agents)
                for agent_report in report.values():
                    installed_skills.update(agent_report["skills"])
                adk_tracker.complete(
                    "adk-verify",
                    f"{len(installed_skills)} skills + MCP for "
                    f"{len(report)} agent(s)",
                )

                adk_tracker.start("adk-skill-contract")
                contract_templates_dir = (
                    project_path
                    / ".lakeforge"
                    / "missions"
                    / PACKAGE_CONFIG[package]["mission"]
                    / "command-templates"
                )
                contract_report = adk.validate_template_skill_declarations(
                    project_path,
                    agents=supported_agents,
                    command_templates_dir=contract_templates_dir,
                )
                template_count = (
                    len(next(iter(contract_report.values()))["templates"])
                    if contract_report
                    else 0
                )
                missing_recommended_union: set[str] = {
                    skill
                    for ar in contract_report.values()
                    for skill in ar.get("missing_recommended", [])  # type: ignore[arg-type]
                }
                contract_detail = (
                    f"{template_count} template(s) checked; all required "
                    "skills installed"
                )
                if missing_recommended_union:
                    contract_detail += (
                        f"; {len(missing_recommended_union)} optional "
                        "skill(s) not installed (informational)"
                    )
                adk_tracker.complete("adk-skill-contract", contract_detail)

                adk_tracker.start("adk-metadata")
                adk.save_metadata(
                    project_path,
                    version=ai_dev_kit_version,
                    skills_profile=skills_profile,
                    agents=supported_agents,
                    installed_skills=installed_skills,
                )
                adk_tracker.complete("adk-metadata", "saved")
            except adk.AiDevKitError as e:
                # Mark the currently-running step as errored so the final
                # tree shows exactly where the install broke.
                for step in adk_tracker.steps:
                    if step["status"] == "running":
                        adk_tracker.error(step["key"], str(e).splitlines()[0])
                        break
                _console.print(adk_tracker.render())
                _console.print()
                _console.print(
                    "[red]Error:[/red] ai-dev-kit installation failed."
                )
                _console.print(str(e))
                _console.print()
                _console.print(
                    f"[yellow]The '{package}' package requires ai-dev-kit. "
                    f"Fix the issue above and re-run "
                    f"[cyan]lakeforge init[/cyan].[/yellow]"
                )
                _console.print(
                    f"[dim]The project directory ({project_path}) is partially "
                    f"initialized; remove it manually if you want to start "
                    f"fresh.[/dim]"
                )
                raise typer.Exit(1)

        _console.print(adk_tracker.render())
        for agent, agent_report in report.items():
            _console.print(
                f"  [dim]{agent}: {len(agent_report['skills'])} skills in "
                f"{agent_report['skill_dir']}, MCP at "
                f"{agent_report['mcp_config']}[/dim]"
            )

    # Telemetry: track init event (track_event handles its own errors)
    from lakeforge_cli.telemetry import track_event
    from lakeforge_cli.telemetry.constants import EVENT_PROJECT_INIT

    track_event(
        EVENT_PROJECT_INIT,
        payload={
            "agent_count": len(selected_agents),
        },
    )

    # Clean up templates directory - it's only needed during init
    # User projects should only have the generated agent commands, not the source templates
    templates_dir = project_path / ".lakeforge" / "templates"
    if templates_dir.exists():
        try:
            shutil.rmtree(templates_dir)
        except PermissionError:
            _console.print("[dim]Note: Could not remove .lakeforge/templates/ (permission denied)[/dim]")
        except Exception as e:
            # Log but don't fail init if cleanup fails
            _console.print(f"[dim]Note: Could not remove .lakeforge/templates/: {e}[/dim]")


def register_init_command(
    app: typer.Typer,
    *,
    console: Console,
    show_banner: Callable[[], None],
    activate_mission: Callable[[Path, str, str, Console], str],
    ensure_executable_scripts: Callable[[Path, StepTracker | None], None],
) -> None:
    """Register the init command with injected dependencies."""
    global _console, _show_banner, _activate_mission, _ensure_executable_scripts

    # Store the dependencies
    _console = console
    _show_banner = show_banner
    _activate_mission = activate_mission
    _ensure_executable_scripts = ensure_executable_scripts

    # Set the docstring
    init.__doc__ = INIT_COMMAND_DOC

    # Ensure app is in multi-command mode by checking if there are existing commands
    # If not, add a hidden dummy command to force subcommand mode
    if not hasattr(app, 'registered_commands') or not getattr(app, 'registered_commands'):
        @app.command("__force_multi_command_mode__", hidden=True)
        def _dummy():
            pass

    # Register the command with explicit name to ensure it's always a subcommand
    app.command("init")(init)
