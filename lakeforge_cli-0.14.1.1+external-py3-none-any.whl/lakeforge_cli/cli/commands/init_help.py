"""Shared help text for the init command."""

INIT_COMMAND_DOC = """
Initialize a new Lakeforge project from templates.

Interactive Mode (default):
- Prompts you to select AI assistants
- Choose agent selection strategy + preferred implementer/reviewer

Non-Interactive Mode:
- Enabled with --non-interactive/--yes, LAKEFORGE_NON_INTERACTIVE=1, or non-TTY
- Skips all prompts
- Uses provided options or defaults (auto-selects preferred strategy if not specified)
- Perfect for CI/CD and automation

What Gets Created:
- .lakeforge/ - Scripts, templates, memory
- Agent commands (.claude/commands/, .codex/prompts/, etc.)
- Context files (CLAUDE.md, .cursorrules, AGENTS.md, etc.)
- Git repository (unless --no-git)
- Background dashboard (http://127.0.0.1:PORT)

⚠️  AFTER INIT, READ BELOW ⚠️
Your next step is to establish project governance using `/constitution`
in the main repo root (NOT in any worktree). This creates project-wide principles
that will guide all subsequent development.

Specifying AI Assistants (--ai flag):
Use comma-separated agent keys (no spaces). Valid keys include:
codex, claude, gemini, cursor, qwen, opencode, windsurf, kilocode,
auggie, roo, copilot, q.

Template Discovery (Development Mode):
By default, lakeforge searches for templates in this order:
  1. --template-root flag (if provided)
  2. LAKEFORGE_TEMPLATE_ROOT environment variable
  3. Packaged templates (from PyPI installation)
  4. LAKEFORGE_TEMPLATE_REPO environment variable (remote)

For development installs from source, use either:
  export LAKEFORGE_TEMPLATE_ROOT=$(pwd) && lakeforge init my-project --ai claude
  OR
  lakeforge init my-project --ai claude --template-root=$(pwd)

Examples:
  lakeforge init my-project                    # Interactive mode
  lakeforge init my-project --ai codex         # Non-interactive with Codex
  lakeforge init my-project --ai codex,claude  # Multiple agents
  lakeforge init my-project --ai codex,claude --script sh
  lakeforge init . --ai codex --force          # Current directory (skip prompts)
  lakeforge init --here --ai claude            # Alternative syntax for current dir
  lakeforge init my-project --ai claude --template-root=/path/to/lakeforge  # Dev mode

Non-interactive automation example:
  lakeforge init my-project --ai codex,claude --script sh --no-git --non-interactive

Missions:
- Missions are selected per-feature during /specify

See docs/non-interactive-init.md for automation patterns and CI examples.
"""
