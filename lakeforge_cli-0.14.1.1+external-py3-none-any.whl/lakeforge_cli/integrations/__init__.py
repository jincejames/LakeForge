"""Integrations with external tools and dependencies."""
