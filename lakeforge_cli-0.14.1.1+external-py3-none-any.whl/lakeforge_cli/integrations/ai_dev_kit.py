"""Integration with ai-dev-kit (https://github.com/databricks-solutions/ai-dev-kit).

Provides Databricks skills + MCP server installation by delegating to
ai-dev-kit's own ``install.sh`` script. Required by lakeforge packages such as
``lakehouse-buildout`` that need deep Databricks expertise and execution
capabilities (see :data:`PACKAGE_CONFIG` in
:mod:`lakeforge_cli.cli.commands.init`).

Why delegate instead of reimplementing
--------------------------------------
ai-dev-kit's installer already handles cloning the repo at a pinned tag,
creating a uv-based venv, editable-installing the MCP server packages,
copying the right skills per agent, and writing per-agent MCP config files
in the formats each agent expects. Reimplementing any of that in lakeforge
would duplicate logic for no benefit; lakeforge instead supplies the right
flags and verifies the deliverables.
"""

from __future__ import annotations

import os
import shutil
import stat
import subprocess
from pathlib import Path
from typing import Iterable

import httpx
from ruamel.yaml import YAML

from lakeforge_cli.core.config import (
    AI_DEV_KIT_DEFAULT_VERSION,
    AI_DEV_KIT_INSTALL_SCRIPT_URL,
    AI_DEV_KIT_REPO,
    AI_DEV_KIT_SKILLS_PROFILES,
    AI_DEV_KIT_SUPPORTED_AGENTS,
)


class AiDevKitError(Exception):
    """Raised when ai-dev-kit setup or verification fails."""


# Per-agent paths that ai-dev-kit's install.sh writes (relative to project root).
# Mirrors the case statements in install.sh ``install_skills`` and
# ``write_mcp_configs`` functions.
AGENT_SKILL_DIRS: dict[str, str] = {
    "claude": ".claude/skills",
    "cursor": ".cursor/skills",
    "copilot": ".github/skills",
    "codex": ".agents/skills",
    "gemini": ".gemini/skills",
}

AGENT_MCP_CONFIG_PATHS: dict[str, str] = {
    "claude": ".mcp.json",
    "cursor": ".cursor/mcp.json",
    "copilot": ".vscode/mcp.json",
    "codex": ".codex/config.toml",
    "gemini": ".gemini/settings.json",
}

# Skills that ai-dev-kit always includes (CORE_SKILLS in install.sh).
# Used as a sanity check during verification.
EXPECTED_CORE_SKILLS: frozenset[str] = frozenset(
    {
        "databricks-config",
        "databricks-docs",
        "databricks-python-sdk",
        "databricks-unity-catalog",
    }
)


def check_prerequisites() -> None:
    """Verify external tools required by ai-dev-kit's installer are on PATH.

    Raises:
        AiDevKitError: If git, uv, or bash are missing, with install hints.
    """
    missing: list[tuple[str, str]] = []
    if shutil.which("git") is None:
        missing.append(("git", "https://git-scm.com/downloads"))
    if shutil.which("uv") is None:
        missing.append(
            ("uv", "https://docs.astral.sh/uv/getting-started/installation/")
        )
    if shutil.which("bash") is None:
        missing.append(("bash", "Required to run ai-dev-kit's install.sh"))

    if missing:
        lines = ["ai-dev-kit installation requires the following tools:"]
        for tool, hint in missing:
            lines.append(f"  - {tool}: {hint}")
        raise AiDevKitError("\n".join(lines))


def validate_agents_supported(
    selected_agents: Iterable[str],
    supported: Iterable[str] = AI_DEV_KIT_SUPPORTED_AGENTS,
) -> list[str]:
    """Filter selected agents to those supported by ai-dev-kit's installer.

    Args:
        selected_agents: Agents the user chose at init time.
        supported: ai-dev-kit-supported agents (overridable for tests).

    Returns:
        Sorted list of supported agents drawn from the user's selection.

    Raises:
        AiDevKitError: If the user picked no supported agents.
    """
    supported_set = set(supported)
    selected_supported = sorted(a for a in selected_agents if a in supported_set)
    if not selected_supported:
        raise AiDevKitError(
            "ai-dev-kit does not support any of the selected agents "
            f"({sorted(selected_agents)}). "
            f"Supported agents: {sorted(supported_set)}. "
            "Either select a supported agent or use a package that does not "
            "require ai-dev-kit."
        )
    return selected_supported


def resolve_version(project_path: Path) -> str:
    """Return the ai-dev-kit version to install for this project.

    Reads ``.lakeforge/config.yaml`` ``ai_dev_kit.version`` if set; otherwise
    falls back to :data:`AI_DEV_KIT_DEFAULT_VERSION` (pinned in lakeforge).
    """
    config_file = project_path / ".lakeforge" / "config.yaml"
    if not config_file.exists():
        return AI_DEV_KIT_DEFAULT_VERSION

    try:
        yaml = YAML()
        with open(config_file) as f:
            config = yaml.load(f) or {}
        version = config.get("ai_dev_kit", {}).get("version")
        if version:
            return str(version)
    except Exception:
        # Treat any parse error as "use default"; init will overwrite later.
        pass

    return AI_DEV_KIT_DEFAULT_VERSION


def download_installer(
    version: str,
    dest_dir: Path,
    *,
    client: httpx.Client | None = None,
) -> Path:
    """Fetch ai-dev-kit's install.sh at ``version`` and make it executable.

    Args:
        version: Git tag or branch (e.g. ``"0.1.10"`` or ``"main"``).
        dest_dir: Directory where install.sh will be saved (created if needed).
        client: Optional httpx client; one is created and closed otherwise.

    Returns:
        Path to the executable installer script.

    Raises:
        AiDevKitError: If the download fails (network error, missing tag).
    """
    url = AI_DEV_KIT_INSTALL_SCRIPT_URL.format(tag=version)
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / "install.sh"

    own_client = client is None
    if own_client:
        client = httpx.Client(timeout=30.0)

    try:
        response = client.get(url, follow_redirects=True)
        response.raise_for_status()
        dest.write_text(response.text)
    except httpx.HTTPError as e:
        raise AiDevKitError(
            f"Failed to download ai-dev-kit installer from {url}: {e}\n"
            f"Check that the version tag '{version}' exists at "
            f"https://github.com/{AI_DEV_KIT_REPO}/tags"
        ) from e
    finally:
        if own_client:
            client.close()

    mode = dest.stat().st_mode
    dest.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return dest


def run_installer(
    installer_path: Path,
    *,
    agents: Iterable[str],
    skills_profile: str,
    version: str,
    project_path: Path,
    timeout: int = 600,
) -> subprocess.CompletedProcess:
    """Invoke ai-dev-kit's install.sh in ``project_path`` as a subprocess.

    Project scope is the installer's default (skills + MCP configs land in the
    cwd rather than the user's home), so no ``--global`` flag is passed.
    ``--silent`` suppresses prompts but errors still go to stderr.

    Args:
        installer_path: Path to the downloaded install.sh.
        agents: Agents to configure (must all be ai-dev-kit-supported).
        skills_profile: Profile name (validated against
            :data:`AI_DEV_KIT_SKILLS_PROFILES`).
        version: Git tag passed via ``--branch``.
        project_path: Working directory; install.sh writes relative to here.
        timeout: Seconds before the subprocess is killed (defaults to 10 min,
            generous for first-time install which clones + builds venv).

    Returns:
        The completed process (returncode == 0).

    Raises:
        AiDevKitError: On unknown profile, timeout, or non-zero exit.
    """
    if skills_profile not in AI_DEV_KIT_SKILLS_PROFILES:
        raise AiDevKitError(
            f"Unknown ai-dev-kit skills profile: {skills_profile!r}. "
            f"Valid profiles: {sorted(AI_DEV_KIT_SKILLS_PROFILES)}"
        )

    cmd = [
        "bash",
        str(installer_path),
        "--tools",
        ",".join(agents),
        "--skills-profile",
        skills_profile,
        "--branch",
        version,
        "--silent",
    ]

    # Defensive env: ensure project scope and silent mode regardless of any
    # DEVKIT_* env vars the user may have exported.
    env = {**os.environ, "DEVKIT_SCOPE": "project", "DEVKIT_SILENT": "true"}

    try:
        return subprocess.run(
            cmd,
            cwd=project_path,
            check=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
        )
    except subprocess.TimeoutExpired as e:
        raise AiDevKitError(
            f"ai-dev-kit installer timed out after {timeout}s. First-time "
            "install clones the repo and builds a venv (this can take several "
            "minutes); subsequent runs are fast."
        ) from e
    except subprocess.CalledProcessError as e:
        raise AiDevKitError(
            f"ai-dev-kit installer failed (exit code {e.returncode}).\n"
            f"--- stderr ---\n{e.stderr or '(empty)'}\n"
            f"--- stdout ---\n{e.stdout or '(empty)'}"
        ) from e


def _resolve_skill_dirs(agents: Iterable[str]) -> dict[str, str]:
    """Map each agent to the relative skill directory the installer used.

    Mirrors the dedup logic in ai-dev-kit's ``install.sh::install_skills``:
    when ``claude`` and ``cursor`` are both selected, the installer only
    creates ``.claude/skills/`` and expects cursor to read from there.

    Returns:
        Mapping from agent name to its resolved relative skill directory.
        Agents not in :data:`AGENT_SKILL_DIRS` are omitted.
    """
    agents_set = set(agents)
    resolved: dict[str, str] = {}
    for agent in agents_set:
        if agent not in AGENT_SKILL_DIRS:
            continue
        if agent == "cursor" and "claude" in agents_set:
            # ai-dev-kit installs to .claude/skills/ only in this case.
            resolved[agent] = AGENT_SKILL_DIRS["claude"]
        else:
            resolved[agent] = AGENT_SKILL_DIRS[agent]
    return resolved


def verify_installation(
    project_path: Path,
    agents: Iterable[str],
) -> dict[str, dict[str, object]]:
    """Confirm skills and MCP configs were created for each agent.

    Args:
        project_path: The lakeforge project root.
        agents: Agents that were passed to the installer.

    Returns:
        Per-agent report mapping agent name to a dict containing the relative
        skill directory path, the list of installed skill names, and the MCP
        config file path.

    Raises:
        AiDevKitError: If any agent is missing its skills directory, core
            skills, or MCP config (with all failures listed).
    """
    report: dict[str, dict[str, object]] = {}
    failures: list[str] = []
    skill_dirs = _resolve_skill_dirs(agents)

    for agent in agents:
        if agent not in AGENT_SKILL_DIRS:
            continue

        skill_rel = skill_dirs[agent]
        mcp_rel = AGENT_MCP_CONFIG_PATHS[agent]
        skill_dir = project_path / skill_rel
        mcp_cfg = project_path / mcp_rel

        if not skill_dir.exists():
            failures.append(f"{agent}: skills directory missing at {skill_rel}")
            continue

        installed_skills = sorted(
            d.name
            for d in skill_dir.iterdir()
            if d.is_dir() and (d / "SKILL.md").exists()
        )

        missing_core = EXPECTED_CORE_SKILLS - set(installed_skills)
        if missing_core:
            failures.append(
                f"{agent}: missing core skills in {skill_rel}: "
                f"{sorted(missing_core)}"
            )

        if not mcp_cfg.exists():
            failures.append(f"{agent}: MCP config missing at {mcp_rel}")
        else:
            content = mcp_cfg.read_text()
            if "databricks" not in content.lower():
                failures.append(
                    f"{agent}: MCP config at {mcp_rel} does not reference "
                    "the databricks server"
                )

        report[agent] = {
            "skill_dir": skill_rel,
            "skills": installed_skills,
            "mcp_config": mcp_rel,
        }

    if failures:
        raise AiDevKitError(
            "ai-dev-kit installation verification failed:\n"
            + "\n".join(f"  - {f}" for f in failures)
        )

    return report


def parse_template_skill_declarations(
    template_path: Path,
) -> dict[str, list[str]]:
    """Extract ``required_skills`` / ``recommended_skills`` from a template's frontmatter.

    The template is a Markdown file whose frontmatter is a YAML block delimited
    by ``---`` lines. Templates may omit the keys; missing or non-list values
    are normalised to an empty list so the validator never crashes on a
    malformed template.

    Returns:
        ``{"required_skills": [...], "recommended_skills": [...]}`` — sorted
        lists of skill names as declared by the template author.
    """
    try:
        text = template_path.read_text(encoding="utf-8")
    except OSError:
        return {"required_skills": [], "recommended_skills": []}

    if not text.startswith("---"):
        return {"required_skills": [], "recommended_skills": []}

    after_first = text[3:]
    end = after_first.find("\n---")
    if end == -1:
        return {"required_skills": [], "recommended_skills": []}

    fm_text = after_first[:end]

    yaml = YAML(typ="safe")
    try:
        data = yaml.load(fm_text) or {}
    except Exception:
        return {"required_skills": [], "recommended_skills": []}

    def _coerce(value: object) -> list[str]:
        if isinstance(value, list):
            return [str(item) for item in value if isinstance(item, str)]
        return []

    return {
        "required_skills": _coerce(data.get("required_skills")),
        "recommended_skills": _coerce(data.get("recommended_skills")),
    }


def collect_template_skill_contract(
    command_templates_dir: Path,
) -> dict[str, dict[str, list[str]]]:
    """Walk a command-templates directory and return per-template skill declarations.

    Templates with no skill declarations are omitted from the result so callers
    can iterate only over those that opt into the contract.
    """
    declarations: dict[str, dict[str, list[str]]] = {}
    if not command_templates_dir.exists():
        return declarations
    for tpl in sorted(command_templates_dir.glob("*.md")):
        decl = parse_template_skill_declarations(tpl)
        if decl["required_skills"] or decl["recommended_skills"]:
            declarations[tpl.name] = decl
    return declarations


def validate_template_skill_declarations(
    project_path: Path,
    *,
    agents: Iterable[str],
    command_templates_dir: Path,
) -> dict[str, dict[str, object]]:
    """Verify every ``required_skills`` declaration is satisfied by the install.

    For each agent, the agent's resolved skill directory (mirroring the dedup
    rule between ``cursor`` and ``claude``) is scanned for installed skills and
    compared against the union of skills declared by templates in
    ``command_templates_dir``. Required skills that are missing for an agent
    fail the validation; recommended skills that are missing are reported but
    do not raise.

    Args:
        project_path: The lakeforge project root (where ai-dev-kit installed).
        agents: Agents that were passed to the installer.
        command_templates_dir: Mission's ``command-templates/`` directory whose
            templates declare the contract.

    Returns:
        Per-agent report mapping agent name to a dict containing:
          - ``templates``: per-template skill declarations
          - ``missing_required``: required skills not installed for this agent
          - ``missing_recommended``: recommended skills not installed
          - ``installed``: skill names actually present in the agent's dir

    Raises:
        AiDevKitError: If any agent is missing one or more required skills, or
            the templates dir does not exist.
    """
    if not command_templates_dir.exists():
        raise AiDevKitError(
            f"command-templates directory not found at {command_templates_dir}; "
            "ai-dev-kit skill-contract validation cannot proceed"
        )

    declarations = collect_template_skill_contract(command_templates_dir)

    union_required: set[str] = {
        skill
        for decl in declarations.values()
        for skill in decl["required_skills"]
    }
    union_recommended: set[str] = {
        skill
        for decl in declarations.values()
        for skill in decl["recommended_skills"]
    }

    skill_dirs = _resolve_skill_dirs(agents)
    report: dict[str, dict[str, object]] = {}
    failures: list[str] = []

    for agent in agents:
        if agent not in skill_dirs:
            continue
        skill_rel = skill_dirs[agent]
        skill_dir = project_path / skill_rel
        if not skill_dir.exists():
            failures.append(
                f"{agent}: skill directory missing at {skill_rel} — cannot "
                "verify skill contract"
            )
            continue

        installed = sorted(
            d.name
            for d in skill_dir.iterdir()
            if d.is_dir() and (d / "SKILL.md").exists()
        )
        installed_set = set(installed)

        missing_required = sorted(union_required - installed_set)
        missing_recommended = sorted(union_recommended - installed_set)

        if missing_required:
            failures.append(
                f"{agent}: command-template skill contract requires skills "
                f"missing from {skill_rel}: {missing_required}. Re-run "
                "lakeforge init with a profile that includes these, or update "
                "the templates."
            )

        report[agent] = {
            "templates": declarations,
            "missing_required": missing_required,
            "missing_recommended": missing_recommended,
            "installed": installed,
        }

    if failures:
        raise AiDevKitError(
            "ai-dev-kit skill-contract validation failed:\n"
            + "\n".join(f"  - {f}" for f in failures)
        )

    return report


def save_metadata(
    project_path: Path,
    *,
    version: str,
    skills_profile: str,
    agents: Iterable[str],
    installed_skills: Iterable[str] | None = None,
) -> None:
    """Persist ai-dev-kit metadata to ``.lakeforge/config.yaml``.

    Adds (or replaces) an ``ai_dev_kit:`` section recording what was installed,
    preserving the rest of the config. The version field becomes the project's
    pinned version for future re-runs (see :func:`resolve_version`).
    """
    config_dir = project_path / ".lakeforge"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / "config.yaml"

    yaml = YAML()
    yaml.preserve_quotes = True

    if config_file.exists():
        with open(config_file) as f:
            config = yaml.load(f) or {}
    else:
        config = {}

    ai_dev_kit_block: dict[str, object] = {
        "version": version,
        "skills_profile": skills_profile,
        "agents": sorted(agents),
    }
    if installed_skills is not None:
        ai_dev_kit_block["installed_skills"] = sorted(set(installed_skills))

    config["ai_dev_kit"] = ai_dev_kit_block

    with open(config_file, "w") as f:
        yaml.dump(config, f)


__all__ = [
    "AGENT_MCP_CONFIG_PATHS",
    "AGENT_SKILL_DIRS",
    "AiDevKitError",
    "EXPECTED_CORE_SKILLS",
    "check_prerequisites",
    "collect_template_skill_contract",
    "download_installer",
    "parse_template_skill_declarations",
    "resolve_version",
    "run_installer",
    "save_metadata",
    "validate_agents_supported",
    "validate_template_skill_declarations",
    "verify_installation",
]
