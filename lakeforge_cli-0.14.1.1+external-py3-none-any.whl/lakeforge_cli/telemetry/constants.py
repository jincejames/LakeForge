"""Telemetry constants for LakeForge CLI."""

from __future__ import annotations

# Telemetry endpoint - Databricks-hosted collector
# TODO: Replace with actual endpoint when provisioned
TELEMETRY_ENDPOINT = "https://telemetry.lakeforge.dev/v1/events"

# HTTP timeout for telemetry POST (seconds)
HTTP_TIMEOUT = 5.0

# Event types
EVENT_CLI_COMMAND = "cli_command"
EVENT_PROJECT_INIT = "project_init"
EVENT_PROJECT_UPGRADE = "project_upgrade"
EVENT_ORCHESTRATE_START = "orchestrate_start"
EVENT_MERGE_COMPLETE = "merge_complete"

# Resource attribution tag keys for Databricks custom_tags.
TAG_PRODUCT = "product"
TAG_PRODUCT_VERSION = "product_version"
TAG_MISSION = "lakeforge_mission"

# Product identifier value
PRODUCT_NAME = "lakeforge"
