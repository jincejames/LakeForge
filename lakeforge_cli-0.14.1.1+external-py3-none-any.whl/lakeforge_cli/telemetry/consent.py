"""Telemetry guard for test/CI environments."""

from __future__ import annotations

import os

# CI environment variables set by popular providers.
_CI_ENV_VARS = (
    "CI",
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "CIRCLECI",
    "TRAVIS",
    "APPVEYOR",
    "BUILDKITE",
    "TEAMCITY_VERSION",
)


def is_test_environment() -> bool:
    """Check if running in a test or CI environment where telemetry should be suppressed."""
    if os.environ.get("LAKEFORGE_TEST_MODE") == "1":
        return True
    return any(os.environ.get(var) for var in _CI_ENV_VARS)
