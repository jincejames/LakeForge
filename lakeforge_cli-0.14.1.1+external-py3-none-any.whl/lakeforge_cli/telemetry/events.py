"""Telemetry event definitions and serialization.

Events contain ONLY aggregate-safe data: command names, counts, version
strings, and platform identifiers. No PII -- not even hashed -- is included.
"""

from __future__ import annotations

import platform
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict

# Strings longer than this are dropped -- they're likely file paths,
# URLs, tokens, or other identifiable data.
_MAX_STRING_LENGTH = 100


def _is_safe_value(value: object) -> bool:
    """Check if a value is safe for telemetry (no PII risk).

    Allows all JSON-serializable primitives (str, int, float, bool)
    and lists of primitives. Only rejects strings that are long enough
    to be paths/URLs/tokens, and complex nested objects.
    """
    if isinstance(value, (int, float, bool)):
        return True
    if isinstance(value, str):
        return len(value) <= _MAX_STRING_LENGTH
    if isinstance(value, list):
        return all(_is_safe_value(item) for item in value)
    return False


def _sanitize_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Drop payload values that could carry PII.

    Keeps all primitive types (str, int, float, bool) and lists of
    primitives. Drops long strings (>100 chars) and nested dicts.
    This is the bare minimum guard to prevent accidental PII leakage
    without restricting metric collection.
    """
    return {k: v for k, v in payload.items() if _is_safe_value(v)}


@dataclass
class TelemetryEvent:
    """An anonymous telemetry event from the LakeForge CLI.

    This schema is intentionally minimal. It contains no data that
    could identify a specific user, project, or organization -- not
    even hashed identifiers. Only aggregate-safe fields are included.

    The payload is lightly sanitized at serialization time: long strings
    and nested objects are dropped to prevent accidental PII leakage.
    """

    event_type: str
    cli_version: str
    python_version: str = field(default_factory=lambda: f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}")
    platform_name: str = field(default_factory=lambda: sys.platform)
    platform_version: str = field(default_factory=platform.platform)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    payload: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a JSON-compatible dictionary with sanitized payload."""
        d = asdict(self)
        d["payload"] = _sanitize_payload(self.payload)
        return d
