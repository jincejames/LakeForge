"""Fire-and-forget HTTP client for telemetry events.

All telemetry transmission is non-blocking and failure-safe.
Telemetry errors must NEVER disrupt CLI operation.
"""

from __future__ import annotations

import logging
import threading

import httpx

from .constants import HTTP_TIMEOUT, TELEMETRY_ENDPOINT
from .events import TelemetryEvent

logger = logging.getLogger(__name__)


def send_event(event: TelemetryEvent) -> None:
    """Send a telemetry event in a background daemon thread.

    This function returns immediately. The HTTP POST runs in a
    daemon thread that will be killed when the main process exits.
    All exceptions are silently caught.
    """

    def _send() -> None:
        try:
            httpx.post(
                TELEMETRY_ENDPOINT,
                json=event.to_dict(),
                timeout=HTTP_TIMEOUT,
                headers={"User-Agent": f"lakeforge-cli/{event.cli_version}"},
            )
        except Exception:  # noqa: BLE001
            # Silent failure - telemetry must never disrupt CLI
            logger.debug("Telemetry event send failed (suppressed)", exc_info=True)

    thread = threading.Thread(target=_send, daemon=True)
    thread.start()
