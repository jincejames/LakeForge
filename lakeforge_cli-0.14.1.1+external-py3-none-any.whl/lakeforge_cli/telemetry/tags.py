"""Resource attribution tag generation for Databricks resources.

Tags are injected into agent templates so that AI agents include
attribution metadata when generating Databricks resource configs.
This enables consumption tracking via system.billing.usage and logfood.

Two complementary mechanisms:
1. custom_tags on resources (clusters, warehouses, jobs, pipelines) --
   queryable via system.billing.usage
2. SDK user-agent via with_user_agent_extra("product", "lakeforge") -- in
   Python code that runs inside Databricks (ETL pipelines, notebooks, jobs)
"""

from __future__ import annotations

from typing import Dict

from .constants import PRODUCT_NAME, TAG_MISSION, TAG_PRODUCT, TAG_PRODUCT_VERSION


def generate_tags(
    version: str,
    mission: str = "",
) -> Dict[str, str]:
    """Generate the standard LakeForge attribution tag dict.

    Args:
        version: LakeForge CLI version (e.g., "0.14.0").
        mission: Mission key (e.g., "databricks-lakehouse-buildout").

    Returns:
        Dict of tag key-value pairs for Databricks custom_tags.
    """
    tags = {
        TAG_PRODUCT: PRODUCT_NAME,
        TAG_PRODUCT_VERSION: version,
    }
    if mission:
        tags[TAG_MISSION] = mission
    return tags


def generate_attribution_block(
    version: str,
    mission: str = "",
) -> str:
    """Generate a markdown instruction block for agent templates.

    This block is inserted into implement.md and similar templates
    to instruct AI agents to tag every Databricks resource they create.

    Args:
        version: LakeForge CLI version.
        mission: Mission key.

    Returns:
        Markdown string with attribution instructions.
    """
    tags = generate_tags(version, mission)
    tags_json = ",\n    ".join(f'"{k}": "{v}"' for k, v in tags.items())

    return f"""
## Resource Attribution (NON-NEGOTIABLE)

Every Databricks resource you create MUST include these custom tags for usage tracking:

```json
{{
    {tags_json}
}}
```

### Method 1: Custom Tags (for resource definitions)

| Resource Type | Where to Add |
|---------------|-------------|
| **Clusters** | `custom_tags` in cluster spec JSON/Terraform |
| **SQL Warehouses** | `tags` in warehouse configuration |
| **Jobs / Workflows** | `tags` on job definition |
| **DLT/SDP Pipelines** | `configuration` map in pipeline settings |
| **Unity Catalog tables/views** | Include in `COMMENT` field |
| **DABs (bundle.yml)** | Add to resource-level `custom_tags` blocks |

### Method 2: SDK User-Agent (for Python code running on Databricks)

ETL pipelines, notebooks, and jobs run inside Databricks with SDK access.
Add this to any Python entry point that uses the Databricks SDK:

```python
from databricks.sdk.config import with_user_agent_extra

with_user_agent_extra("product", "lakeforge")
with_user_agent_extra("product_version", "{version}")
```

This registers LakeForge in the SDK's HTTP user-agent header, enabling
server-side tracking of API calls originating from LakeForge-generated code.

**Both methods MUST be applied. Failure to include attribution is a review blocker.**
"""
