"""Privacy-preserving hashing utilities.

Note: This module exists for internal use only (e.g., migration project IDs).
Hashed values are NOT sent in telemetry events -- telemetry contains
zero PII, not even hashed. This module is used only for local purposes
like generating stable resource identifiers.
"""

from __future__ import annotations

import hashlib

# Truncation length for hashed identifiers (hex chars)
_HASH_LENGTH = 16


def hash_identifier(value: str) -> str:
    """Hash an identifier using SHA-256, truncated.

    Used internally for stable project identifiers in migration metadata.
    NOT used for telemetry transmission.

    Args:
        value: The string to hash.

    Returns:
        Truncated hex digest (16 chars).
    """
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:_HASH_LENGTH]
