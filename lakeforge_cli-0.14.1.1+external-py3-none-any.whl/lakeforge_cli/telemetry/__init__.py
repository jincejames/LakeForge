"""LakeForge telemetry - usage analytics and resource attribution.

Two independent layers:
1. CLI-side telemetry: anonymous command usage events sent to a collector
2. Resource attribution: tags injected into templates for Databricks resource tracking

No PII is ever collected -- not even hashed. Only aggregate-safe data
(command names, counts, CLI version, OS platform) is transmitted.
All network failures are silent.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from .events import TelemetryEvent

logger = logging.getLogger(__name__)


def track_event(
    event_type: str,
    payload: Optional[Dict[str, Any]] = None,
) -> None:
    """Track a telemetry event. Fails silently on any error.

    This is the primary public API. All telemetry calls go through here.
    If there are any network restrictions or errors, it fails silently.

    Args:
        event_type: Event type constant (e.g., EVENT_CLI_COMMAND).
        payload: Event-specific data. Must contain only aggregate-safe
                 values (counts, command names, version strings).
                 Never include project paths, user names, tokens, or
                 any data that could identify a specific user or project.
    """
    try:
        from .consent import is_test_environment

        if is_test_environment():
            return

        from lakeforge_cli import __version__

        event = TelemetryEvent(
            event_type=event_type,
            cli_version=__version__,
            payload=payload or {},
        )

        from .client import send_event

        send_event(event)
    except Exception:  # noqa: BLE001
        # Telemetry must never disrupt CLI operation
        logger.debug("Telemetry tracking failed (suppressed)", exc_info=True)


__all__ = [
    "track_event",
]
