---
description: Generate work packages organized by lakehouse phases.
required_skills:
  - databricks-spark-declarative-pipelines
  - databricks-unity-catalog
  - databricks-dbsql
recommended_skills:
  - databricks-jobs
  - databricks-bundles
  - databricks-metric-views
  - databricks-spark-structured-streaming
  - databricks-zerobus-ingest
---

# /tasks - Generate Lakehouse Work Packages

**Version**: 0.11.0+

## ⚠️ CRITICAL: THIS IS THE MOST IMPORTANT PLANNING WORK

**You are creating the blueprint for lakehouse implementation**. The quality of work packages determines:
- How easily agents can implement each layer
- How parallelizable the work is
- How reviewable the code will be
- Whether the lakehouse succeeds or fails

**QUALITY OVER SPEED**: This is NOT the time to save tokens or rush.

---

## 📍 WORKING DIRECTORY: Stay in MAIN repository

**IMPORTANT**: Tasks works in the main repository. NO worktrees created.

```bash
# Run from project root (same directory as /plan):
# Creates:
# - lakeforge-specs/###-feature/tasks/WP01-*.md → In main repository
# - lakeforge-specs/###-feature/tasks/WP02-*.md → In main repository
# - Commits ALL to main branch
# - NO worktrees created
```

**Worktrees created later**: After tasks are generated, use `lakeforge implement WP##` to create workspace for each WP.

## Pre-flight (read first)

Before deriving subtasks, open and follow `.lakeforge/missions/databricks-lakehouse-buildout/_databricks-context.md`. It defines the operating contract, the strict best-practices enforcement rules every WP must respect, and the 8 Lakehouse Principles.

**Task-generation invariants** (specialised from `_databricks-context.md`):

1. **Bronze-first is non-negotiable** — every external source gets Bronze landing subtasks before any Silver subtask references it.
2. **Quality gates before Gold are mandatory** — every feature gets at least one quality-gate subtask between Silver and Gold.
3. **No tasks for non-compliant patterns** — if `plan.md` contains a pattern that contradicts the rules in `_databricks-context.md` (DBFS for prod, generic JDBC, layer skipping, `SELECT *` in Gold views, etc.), flag the plan first, then generate the best-practice alternative subtask.
4. **Cite a skill on every subtask** — each generated subtask must name the `ai-dev-kit` skill the implementer will consult; the catalog lives at `.lakeforge/missions/databricks-lakehouse-buildout/SKILLS_GUIDE.md`.

### Phase → recommended skill hints

When you write each WP frontmatter (Step 6), populate `skill_hints` and `mcp_tools` from the table below. These are **hints**, not requirements — the implementer adapts to the actual subtasks at `/implement` time.

| Phase / WP role | `skill_hints` (suggested) | `mcp_tools` (suggested) |
|------------------|----------------------------|--------------------------|
| Bronze infrastructure (schemas, tables) | `databricks-unity-catalog`, `databricks-spark-declarative-pipelines` | `manage_uc_objects`, `execute_sql` |
| Bronze source connector (Auto Loader / native) | `databricks-spark-declarative-pipelines` | `manage_pipeline`, `execute_sql` |
| Bronze custom Spark source | `spark-python-data-source`, `databricks-python-sdk` | `execute_code` |
| Bronze real-time gRPC ingest | `databricks-zerobus-ingest` | (none — producer external) |
| Bronze landing validation | `databricks-spark-declarative-pipelines`, `databricks-dbsql` | `execute_sql`, `get_table_stats_and_schema` |
| Silver mapping / transformation | `databricks-spark-declarative-pipelines` | `manage_pipeline`, `execute_sql` |
| Silver CDC / SCD-2 (`apply_changes`) | `databricks-spark-declarative-pipelines` | `manage_pipeline` |
| Silver custom streaming | `databricks-spark-structured-streaming` | `execute_code`, `manage_cluster` |
| Silver pre-Gold validation | `databricks-spark-declarative-pipelines`, `databricks-dbsql` | `execute_sql`, `get_table_stats_and_schema` |
| Gold table / view DDL | `databricks-dbsql`, `databricks-unity-catalog` | `execute_sql`, `manage_uc_objects` |
| Gold metric / KPI views | `databricks-metric-views` | `manage_metric_views` |
| Gold optimization (Z-order, statistics) | `databricks-dbsql` | `execute_sql`, `get_table_stats_and_schema` |
| Gold security / ACLs | `databricks-unity-catalog` | `manage_uc_grants` |
| Iceberg interop (rare) | `databricks-iceberg` | `manage_uc_objects`, `execute_sql` |
| Quality-gate implementation | `databricks-unity-catalog` (monitors), `databricks-spark-declarative-pipelines` | `manage_uc_monitors`, `execute_sql` |
| Test-data / synthetic seed | `databricks-synthetic-data-gen` | `execute_code` |
| Orchestration / job DAG | `databricks-jobs` | `manage_jobs`, `manage_job_runs` |
| Asset Bundles / CI deploy | `databricks-bundles` | (CLI: `databricks bundle deploy`) |
| Documentation / runbook | (no skill required) | (none) |

If a needed skill is not installed under `.cursor/skills/` (or `.claude/skills/`), surface that to the user and ask them to re-run `lakeforge init lakehouse-buildout --ai <agent>` rather than improvising. Do **not** live-fetch the Databricks docs sitemap — the `databricks-docs` skill already indexes it.

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Location Check (0.11.0+)

Before proceeding, verify you are in the main repository:

```bash
git branch --show-current
```

**Expected output:** `main` (or `master`)

Work packages are generated directly in `lakeforge-specs/###-feature/` and committed to main.

## Lakehouse-Phased Work Package Organization

Work packages MUST be organized by lakehouse phases:

### Phase 1: Bronze Layer (Foundation)

**Goal**: Land raw data with zero transformations

Typical WPs:
- WP01: Bronze infrastructure (schemas, tables)
- WP02: Source connector implementation
- WP03: Landing validation

**Parallelization**: Multiple sources can be landed in parallel

**Subtask examples**:
- T001 Create Bronze schema `dw_bronze`
- T002 [P] Create source connector configuration for Source A
- T003 [P] Create source connector configuration for Source B
- T004 [P] Create landing tables with metadata columns
- T005 Implement landing validation (distinct counts, time ranges)

### Phase 2: Silver Layer (Transformation)

**Goal**: Validate, transform, and historize data

**Dependencies**: Depends on Phase 1 completion for relevant sources

Typical WPs:
- WP04: Mapping implementation
- WP05: CDC/SCD Type-2 implementation
- WP06: Silver validation

**Subtask examples**:
- T006 Create Silver schema `dw_silver`
- T007 Implement mappings from Bronze
- T008 Implement CDC (Type-2 SCD with start_date, end_date, is_current)
- T009 Add validation rules before Gold promotion

### Phase 3: Gold Layer (Delivery)

**Goal**: Create customer-facing views and optimize

**Dependencies**: Depends on Phase 2 completion

Typical WPs:
- WP07: Gold view creation
- WP08: Quality gate implementation
- WP09: Optimization (Z-ordering, statistics)
- WP10: Security configuration (ACLs)

**Subtask examples**:
- T010 Create Gold schemas (`gold_etl`, `gold`, `gold_hist`)
- T011 Create Gold tables with explicit column naming
- T012 Create customer-facing views (no SELECT *)
- T013 Implement quality gates (range, cross-field, statistical)
- T014 Apply optimization (Z-ordering, statistics)
- T015 Configure ACLs

### Phase 4: Documentation (Close)

**Goal**: Document and hand off

**Dependencies**: Depends on Phases 1-3 completion

Typical WPs:
- WP11: Technical documentation
- WP12: Runbook and operations guide

**Subtask examples**:
- T016 Technical documentation (architecture, data flows)
- T017 Runbook for operations
- T018 Data dictionary (column definitions, business rules)

### Phase Dependencies Diagram

```
Phase 1 (Bronze)
  └─→ Phase 2 (Silver)
       └─→ Phase 3 (Gold)
            └─→ Phase 4 (Docs)

Parallelization within Phase 1:
  Source A Bronze ──┐
  Source B Bronze ──┼─→ Phase 2 (when all sources ready)
  Source C Bronze ──┘
```

## Outline

### Step 1: Setup

Run `lakeforge agent feature check-prerequisites --json --paths-only --include-tasks` and capture `FEATURE_DIR`.

### Step 2: Load Design Documents

Read from `FEATURE_DIR`:
- spec.md (required) - Data sources, layer requirements
- plan.md (required) - Lakehouse architecture design
- data-model.md (optional) - Entity definitions

### Step 3: Derive ALL Subtasks

Create complete list of subtasks with IDs T001, T002, etc.

**Lakehouse-specific subtask categories**:
- Bronze landing (per source)
- Bronze validation
- Silver transformation (per entity)
- Silver CDC/historization
- Silver validation
- Gold table creation
- Gold view creation
- Quality gate implementation
- Optimization (Z-ordering, statistics)
- Security (ACLs)
- Documentation

### Step 4: Group into Work Packages by Phase

**Grouping by lakehouse phase**:

| Phase | WP Range | Goal |
|-------|----------|------|
| Bronze | WP01-WP03 | Land raw data |
| Silver | WP04-WP06 | Transform and historize |
| Gold | WP07-WP10 | Deliver to customers |
| Docs | WP11-WP12 | Document and close |

**Sizing guidelines**:
- Target: 3-7 subtasks per WP (200-500 line prompts)
- Maximum: 10 subtasks per WP (700 line prompts)
- If more than 10 subtasks: Create additional WPs

### Step 5: Write tasks.md

Use the lakehouse tasks scaffold (`tasks-template.md`) from this mission's `templates` directory under `.lakeforge/missions/databricks-lakehouse-buildout/`:

- **Location**: Write to `FEATURE_DIR/tasks.md`
- Organize by lakehouse phases (Bronze, Silver, Gold, Docs)
- Include path conventions (dw_bronze., dw_silver., gold_etl., gold., gold_hist.)
- Include phase dependency diagram

### Step 6: Generate WP Prompt Files

For each WP, generate `FEATURE_DIR/tasks/WPxx-slug.md`. Each WP file must include:

**a) `skill_hints` and `mcp_tools` in the WP frontmatter** — pick from the "Phase → recommended skill hints" table in the Pre-flight section, narrowed to what this WP's subtasks actually need. Implementers will consult these skills/tools at `/implement` time instead of refetching Databricks docs.

**b) A short "Skill consultation" section in the WP body** (replaces the legacy "Databricks Documentation Reference" block):

```markdown
## Skill consultation

Before implementing the subtasks in this WP, open the corresponding skill `SKILL.md`
files under `.cursor/skills/` (or `.claude/skills/`):

- [list each skill from the WP frontmatter `skill_hints`]

For live workspace operations, prefer these MCP tools over the Databricks CLI:

- [list each tool from the WP frontmatter `mcp_tools`]

The shared partial at `.lakeforge/missions/databricks-lakehouse-buildout/_databricks-context.md`
remains authoritative for the operating contract and the 8 Lakehouse Principles.
```

**c) The correct implementation command**:
- Phase 1 WPs: `lakeforge implement WP01`
- Phase 2 WPs: `lakeforge implement WP04 --base WP03`
- Phase 3 WPs: `lakeforge implement WP07 --base WP06`
- Phase 4 WPs: `lakeforge implement WP11 --base WP10`

### Step 7: Finalize Tasks

Run `lakeforge agent feature finalize-tasks --json` to:
- Parse dependencies
- Update frontmatter
- Validate (cycles, invalid refs)
- Commit to main

### Step 8: Report

Provide summary with:
- WP count and subtask tallies per phase
- Phase dependencies
- Parallelization opportunities (especially within Bronze)
- MVP scope (typically Phase 1 + Phase 2 + Phase 3)

## Dependency Detection (0.11.0+)

**Generate dependencies, skill hints, and MCP-tool hints in each WP frontmatter**:

```yaml
---
work_package_id: "WP04"
title: "Silver Transformation"
phase: "Phase 2 - Silver Layer"
lane: "planned"
dependencies: ["WP01", "WP02", "WP03"]  # All Bronze WPs
subtasks: ["T006", "T007", "T008", "T009"]
skill_hints:
  - databricks-spark-declarative-pipelines  # apply_changes for SCD-2
  - databricks-dbsql                        # pre-Gold validation queries
mcp_tools:
  - manage_pipeline                         # create/update SDP
  - execute_sql                             # validation queries
  - get_table_stats_and_schema              # introspect Silver tables
---
```

The `skill_hints` and `mcp_tools` lists are read by `/implement` to drive its skill-consultation step. Pick names from the "Phase → recommended skill hints" table in the Pre-flight section.

**Phase-based dependency patterns**:
- Phase 1 WPs: No dependencies (foundation)
- Phase 2 WPs: Depend on relevant Phase 1 WPs
- Phase 3 WPs: Depend on relevant Phase 2 WPs
- Phase 4 WPs: Depend on all previous phases

## Work Package Sizing Guidelines

### Ideal WP Size

**Target: 3-7 subtasks per WP**
- Results in 200-500 line prompt files
- Agent can hold entire context
- Clear scope - easy to review

**Examples of well-sized lakehouse WPs**:

- WP01: Bronze Infrastructure (4 subtasks, ~280 lines)
  - T001: Create Bronze schema
  - T002: Configure connector for Source A
  - T003: Create landing tables
  - T004: Add metadata columns

- WP04: Silver Transformation (5 subtasks, ~350 lines)
  - T010: Create Silver schema
  - T011: Implement mappings
  - T012: Implement CDC (Type-2 SCD)
  - T013: Add historization columns
  - T014: Pre-Gold validation

### Maximum WP Size

**Hard limit: 10 subtasks, ~700 lines**

If you need more than 10 subtasks: SPLIT by sub-concern within the phase.

Example split for complex Bronze:
- WP01: Bronze Schema & Core Tables (5 subtasks)
- WP02: Bronze Source Connectors (5 subtasks)
- WP03: Bronze Validation & Optimization (4 subtasks)

## Remember

**Lakehouse architecture requires disciplined layer progression.**

A well-crafted set of phase-organized work packages ensures:
- Bronze lands cleanly before Silver transforms
- Silver validates before Gold publishes
- Quality gates prevent bad data from reaching customers
- Documentation captures the full data lineage

**Invest the tokens now. Be thorough. Future data engineers will thank you.**
