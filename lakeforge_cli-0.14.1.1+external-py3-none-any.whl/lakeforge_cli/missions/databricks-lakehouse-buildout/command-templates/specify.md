---
description: Create lakehouse feature specification with Bronze-first requirements.
required_skills:
  - databricks-config
  - databricks-docs
recommended_skills:
  - databricks-unity-catalog
---

# /specify - Create Lakehouse Feature Specification

**Version**: 0.11.0+

## 📍 WORKING DIRECTORY: Stay in MAIN repository

**IMPORTANT**: Specify works in the main repository. NO worktrees are created.

```bash
# Run from project root:
cd /path/to/project/root  # Your main repository

# All planning artifacts are created in main and committed:
# - lakeforge-specs/###-feature/spec.md → Created in main
# - Committed to main branch
# - NO worktrees created
```

**Worktrees are created later** during `/implement`, not during planning.

## Pre-flight (read first)

Before doing anything else, open and follow the shared partial at `.lakeforge/missions/databricks-lakehouse-buildout/_databricks-context.md`. It defines the operating contract, best-practices enforcement, and the 8 Lakehouse Principles that govern this mission.

For `/specify` specifically, the relevant skills installed by `ai-dev-kit` are:

- **`databricks-config`** — confirm the active workspace before discovery. If no host/profile is configured, surface that to the user immediately rather than asking guesswork questions. The matching MCP tool is `manage_workspace`.
- **`databricks-docs`** — verify Databricks terminology and auto-correct deprecated names. **Replaces** any prior live-fetch of the Databricks docs sitemap; do not refetch documentation URLs at runtime (the skill already indexes them).

The full phase → skill → MCP-tool catalog lives at `.lakeforge/missions/databricks-lakehouse-buildout/SKILLS_GUIDE.md`.

**Auto-correction example** (as defined by `databricks-docs`):

> User: "I want to use DLT"
> Agent: "Note: per the `databricks-docs` skill, DLT is now called 'Lakeflow Declarative Pipelines'. [See docs](https://docs.databricks.com/ldp/)"

If the `databricks-docs` skill is missing from `.cursor/skills/` (or `.claude/skills/`), ask the user to re-run `lakeforge init lakehouse-buildout --ai <agent>` rather than improvising.

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Discovery Gate (mandatory)

Before running any scripts or writing to disk you **must** conduct a structured discovery interview.

### Lakehouse Discovery Questions

In addition to standard discovery, ask these lakehouse-specific questions:

**Data Source Classification** - For each data source the user mentions, classify:
- **Class**: Small (<1GB), Medium (1-100GB), Large (>100GB)
- **Type**: Type-2 (tracks changes) or Non-Type-2
- **Schema**: Known/evolving/unknown
- **Sensitivity**: PII, Confidential, Public
- **Ingestion Strategy**: Full refresh (small only), Incremental, CDC

**Layer Strategy**:
- Will this feature touch Bronze, Silver, and/or Gold layers?
- Are there existing tables in any layer to integrate with?
- What is the expected data volume at each layer?

**Quality Gates**:
- What validation rules must pass before data moves to Gold?
- Are there specific business rules for data quality?
- How should failed records be handled (quarantine, reject, alert)?

**Example Discovery Question with Doc Link**:
> "Will you use Liquid Clustering for your Delta tables? [docs.databricks.com/delta/clustering.html]
> This is recommended for tables with high-cardinality columns."

### Scope Proportionality

- **Scope proportionality (CRITICAL)**: FIRST, gauge the inherent complexity of the request:
  - **Trivial/Test Features** (simple pipeline test, proof-of-concept): Ask 1-2 questions maximum, then proceed.
  - **Simple Features** (single source landing, basic transformation): Ask 2-3 questions covering purpose and data characteristics
  - **Complex Features** (multi-source integration, complex CDC): Ask 3-5 questions covering sources, transformation logic, quality rules
  - **Platform/Critical Features** (data governance, security, compliance): Full discovery with 5+ questions

- **User signals to reduce questioning**: If the user says "just testing", "quick prototype", "skip to next phase", "stop asking questions" - recognize this as a signal to minimize discovery and proceed with reasonable defaults.

- **First response rule**:
  - For TRIVIAL features: Ask ONE clarifying question about data source, then proceed directly to spec generation
  - For other features: Ask a single focused discovery question and end with `WAITING_FOR_DISCOVERY_INPUT`

### Discovery Requirements

1. Maintain a **Discovery Questions** table internally covering questions appropriate to the feature's complexity (1-2 for trivial, up to 5+ for complex). Track columns `#`, `Question`, `Why it matters`, and `Current insight`. Do **not** render this table to the user.
2. For trivial features, reasonable defaults are acceptable. Only probe if truly ambiguous.
3. When you have sufficient context for the feature's scope, paraphrase into an **Intent Summary** and confirm.
4. If user explicitly asks to skip questions, acknowledge and proceed with minimal discovery.

## Mission Selection

After completing discovery and confirming the Intent Summary, the mission is **databricks-lakehouse-buildout**.

Store `"databricks-lakehouse-buildout"` as the mission selection in your notes and include it in the spec output.

## Workflow (0.11.0+)

**Planning happens in main repository - NO worktree created!**

1. Creates `lakeforge-specs/###-feature/spec.md` directly in main repo
2. Automatically commits to main branch
3. No worktree created during specify

**Worktrees created later**: Use `lakeforge implement WP##` to create a workspace for each work package.

## Location

- Work in: **Main repository** (not a worktree)
- Creates: `lakeforge-specs/###-feature/spec.md`
- Commits to: `main` branch

## Outline

### 1. Generate a Friendly Feature Title

- Summarize the agreed intent into a short, descriptive title (aim for ≤7 words; avoid filler like "feature" or "thing").
- Use lakehouse terminology where appropriate (Bronze, Silver, Gold, CDC, etc.)
- Use the confirmed title to derive the kebab-case feature slug for the create-feature command.

### 2. Check Discovery Status

- If this is your first message or discovery questions remain unanswered, stay in the one-question loop, capture the user's response, update your internal table, and end with `WAITING_FOR_DISCOVERY_INPUT`.
- Only proceed once every discovery question has an explicit answer and the user has acknowledged the Intent Summary.

### 3. Create Feature

When discovery is complete and the intent summary, **title**, and **mission** are confirmed:

```bash
lakeforge agent feature create-feature "<slug>" --json
```

Parse the JSON for `feature`, `feature_dir`, and `result`.

### 4. Create meta.json

```json
{
  "feature_number": "<number>",
  "slug": "<full-slug>",
  "friendly_name": "<Friendly Title>",
  "mission": "databricks-lakehouse-buildout",
  "source_description": "$ARGUMENTS",
  "created_at": "<ISO timestamp>"
}
```

### 5. Generate Specification

Use the lakehouse spec scaffold (`spec-template.md`) from this mission's `templates` directory under `.lakeforge/missions/databricks-lakehouse-buildout/` to generate:

- User Scenarios & Testing (mandatory)
- Data Sources section with source classification table
- Layer Requirements section for Bronze/Silver/Gold expectations
- Quality Gates section for validation rules
- Functional Requirements (mandatory)
- Success Criteria (mandatory)

### 6. Specification Quality Validation

Create checklist at `FEATURE_DIR/checklists/requirements.md`:

```markdown
# Specification Quality Checklist: [FEATURE NAME]

**Purpose**: Validate specification completeness and quality before proceeding to planning
**Created**: [DATE]
**Feature**: [Link to spec.md]

## Content Quality

- [ ] No implementation details (languages, frameworks, APIs)
- [ ] Focused on data pipeline value and business needs
- [ ] Written for non-technical stakeholders
- [ ] All mandatory sections completed

## Lakehouse-Specific Validation

- [ ] Data sources classified (Class, Type, Schema, Sensitivity)
- [ ] Layer requirements defined (Bronze, Silver, Gold)
- [ ] Quality gates specified
- [ ] Ingestion strategy documented for each source

## Requirement Completeness

- [ ] No [NEEDS CLARIFICATION] markers remain
- [ ] Requirements are testable and unambiguous
- [ ] Success criteria are measurable
- [ ] Success criteria are technology-agnostic
- [ ] All acceptance scenarios are defined
- [ ] Edge cases are identified
- [ ] Scope is clearly bounded

## Notes

- Items marked incomplete require spec updates before `/clarify` or `/plan`
```

### 7. Report Completion

Report completion with feature directory, spec file path, checklist results, and readiness for the next phase (`/clarify` or `/plan`).

## General Guidelines

### Quick Guidelines

- Focus on **WHAT** data needs to flow and **WHY**.
- Avoid HOW to implement (no specific SQL, PySpark code, etc.).
- Written for business stakeholders, not data engineers.
- DO NOT create any checklists that are embedded in the spec.

### Lakehouse-Specific Guidelines

- Always classify data sources before designing transformations
- Bronze layer: Raw data, no transformations
- Silver layer: Validated, historized, business-logic applied
- Gold layer: Customer-facing, aggregated, optimized
- Quality gates are NON-NEGOTIABLE between Silver and Gold

### For AI Generation

When creating this spec from a user prompt:

1. **Consult `databricks-docs` first**: verify current Databricks terminology before posing discovery questions; do not live-fetch the docs sitemap (the skill already has it indexed).
2. **Auto-correct deprecated terms**: explain the correction and cite the canonical doc URL surfaced by the `databricks-docs` skill.
3. **Make informed guesses**: Use context, the lakehouse best-practice rules in `_databricks-context.md`, and the 8 Lakehouse Principles.
4. **Document assumptions**: Record defaults in the Assumptions section.
5. **Limit clarifications**: Maximum 3 [NEEDS CLARIFICATION] markers.
6. **Include doc links**: When referencing Databricks features, prefer URLs returned by `databricks-docs` over hand-typed paths (which may be stale).

**Common areas needing clarification**:
- Data source connectivity (how to access source system)
- Data volume and growth expectations
- SLA requirements (how fresh must data be)
- Security/compliance requirements (PII handling)

**Reasonable defaults** (don't ask about these unless user signals otherwise):
- Use Delta Lake format
- Use Unity Catalog for governance
- Standard medallion architecture (Bronze → Silver → Gold)
- Type-2 SCD for dimension tracking
- Quality gates before Gold promotion
