---
description: Verify lakehouse architecture compliance for feature acceptance.
required_skills:
  - databricks-unity-catalog
  - databricks-spark-declarative-pipelines
recommended_skills:
  - databricks-dbsql
  - databricks-jobs
  - databricks-bundles
  - databricks-metric-views
---

# /accept - Lakehouse Feature Acceptance

**Version**: 0.11.0+
**Purpose**: Validate all work packages are complete and lakehouse architecture is compliant.

## 📍 WORKING DIRECTORY: Run from MAIN repository

**IMPORTANT**: Accept runs from the main repository root, NOT from a WP worktree.

```bash
# If you're in a worktree, return to main first:
cd $(git rev-parse --show-toplevel)

# Then run accept:
lakeforge accept
```

## Pre-flight (read first)

Before invoking the acceptance workflow:

1. **Open and follow** `.lakeforge/missions/databricks-lakehouse-buildout/_databricks-context.md` for the operating contract and the 8 Lakehouse Principles. The "Zero-tolerance violations" listed there (any principle violation, missing Bronze layer, missing quality gates, missing historization, non-Delta formats, customer access to tables instead of views) are **automatic-rejection** triggers.
2. **Treat acceptance as the final gate**. At this stage the static review (`/review`) already passed; `/accept` adds **live ground-truth verification** by querying the Databricks workspace's system tables — the implementation is verified against the running system, not just the source code.
3. **The acceptance rule**: any single best-practice violation is rejection-worthy regardless of functional correctness.

**Acceptance blockers** (cannot accept if any present):
- ANY violation of the 8 Lakehouse Principles & Databricks Well-Architected pillars (the "Additional Mandatory Control: Databricks Well-Architected Final Verification" checklist below is part of this gate)
- Patterns contradicting documented best practices
- Missing Bronze layer for any data source
- Missing quality gates before Gold
- Direct table access instead of views in Gold
- Non-Delta formats for lakehouse tables

The full skill catalog lives at `.lakeforge/missions/databricks-lakehouse-buildout/SKILLS_GUIDE.md`. Do **not** live-fetch the Databricks docs sitemap — the `databricks-docs` skill already indexes it.

### UC system-table acceptance playbook

Run each probe below via the **`execute_sql`** MCP tool against the active workspace. The corresponding skill is `databricks-unity-catalog` (UC system tables) and `databricks-spark-declarative-pipelines` (pipeline state). Record each result alongside the matching row in the Acceptance Criteria Sign-Off table.

| Acceptance dimension | System table(s) to query | What to verify |
|----------------------|---------------------------|----------------|
| Resource attribution (Principle VIII) | `system.access.audit` (filter `service_name in ('jobs','pipelines','sql')`); `system.compute.warehouses`, `system.compute.clusters`; `system.lakeflow.pipelines` | Confirm `tags`/`custom_tags` include `product=lakeforge` on every job, warehouse, cluster, and pipeline created for this feature. |
| Lineage | `system.access.table_lineage` | Confirm flow Bronze → Silver → Gold for every Gold view; flag any Gold object with no upstream Silver lineage as a layer-skip violation. |
| Pipeline health | `system.lakeflow.pipelines`, `system.lakeflow.pipeline_updates` | Latest update for each SDP pipeline must be `COMPLETED` (not `FAILED`/`CANCELED`); use `manage_pipeline_run` (MCP) for the deeper run history if a probe is ambiguous. |
| Job health | `system.lakeflow.jobs`, `system.lakeflow.job_run_timeline`, `system.lakeflow.job_task_run_timeline` | Recent runs of every Gold-publishing job must succeed; use `manage_job_runs` (MCP) for the run detail. |
| Quality gates / monitoring | `system.access.audit` (filter `action_name like 'monitor%'`); plus `manage_uc_monitors` (MCP) | A Lakehouse Monitor exists for the Silver→Gold boundary and has a recent successful run; failed-record routing to a `*_quarantine` table is observable. |
| Storage and table format | `system.information_schema.tables` (filter `table_catalog`/`table_schema` for this feature) | Every lakehouse table is `MANAGED` Delta (not external Parquet/CSV); no `dbfs:/mnt/` paths in Bronze. |
| Cost / billing sanity | `system.billing.usage` (filter by tag `product=lakeforge` and the feature's compute resources) | Compute usage during the build window is non-zero (proves end-to-end execution actually ran) and within the order-of-magnitude expected from the plan. |
| Customer access (Principle VII) | `system.information_schema.table_privileges`, `system.information_schema.routine_privileges` | Customer principals have `SELECT` only on `gold.v_*` views; no grants on `gold_etl.*` or `gold_hist.*`; use `manage_uc_grants` (MCP) to confirm before tightening. |

**Skill cross-reference**: when a probe surfaces an anomaly, open the corresponding skill (`databricks-unity-catalog` for grants/lineage/monitors, `databricks-spark-declarative-pipelines` for pipeline state, `databricks-jobs` for job state, `databricks-dbsql` for warehouse-side checks) and cite the exact pattern that should have been followed in the rejection note.

**Well-Architected pillar evidence**: for the Well-Architected acceptance checklist below, consult the `databricks-docs` skill for the AWS / Azure / GCP `lakehouse-architecture/well-architected` pillar pages. Cite the URL the skill returns alongside each pillar checkbox; do not mark a pillar PASS using only the general best-practices page.

---

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

---

## Lakehouse Architecture Final Validation

### Pre-Acceptance Checklist

**Layer Completion**:
- [ ] Bronze layer: All sources landing correctly
- [ ] Silver layer: CDC and historization complete
- [ ] Gold layer: Views and optimization in place
- [ ] Documentation: Complete and accurate

**Architecture Compliance**:
- [ ] Bronze-first landing verified (no direct Silver/Gold writes)
- [ ] Layer progression verified (Bronze → Silver → Gold)
- [ ] Quality gates operational between Silver and Gold
- [ ] Incremental ingestion working (no full pulls for large sources)
- [ ] CDC and historization validated (Type-2 SCD)
- [ ] Optimization applied (Z-ordering, statistics)
- [ ] View abstraction in place (no direct table access)

**Quality Assurance**:
- [ ] All quality gates passing
- [ ] Failed records properly routed to quarantine
- [ ] No data quality regressions
- [ ] Alerting configured for gate failures

---

## Database Naming Verification

Verify naming conventions match standard lakehouse patterns:

| Layer | Expected Database | Actual | Status |
|-------|-------------------|--------|--------|
| Bronze | `dw_bronze` | | [ ] Verified |
| Silver | `dw_silver` | | [ ] Verified |
| Gold (tables) | `gold_etl` | | [ ] Verified |
| Gold (views) | `gold` | | [ ] Verified |
| Gold (history) | `gold_hist` | | [ ] Verified |

---

## 8 Lakehouse Principles Final Verification

| Principle | Requirement | Live evidence (MCP probe) | Verified |
|-----------|-------------|----------------------------|----------|
| I. Bronze-First | All sources land in Bronze first, no transformations | `execute_sql` on `system.access.table_lineage` shows raw sources land in `dw_bronze.*` only | [ ] |
| II. Layer Separation | Data progresses Bronze → Silver → Gold (no skips) | `execute_sql` on `system.access.table_lineage` shows no Gold object with a Bronze (or external) parent | [ ] |
| III. Quality Gates | Validation before Gold promotion (NON-NEGOTIABLE) | `manage_uc_monitors` lists a monitor on the Silver→Gold boundary with a recent successful run | [ ] |
| IV. Incremental | No full pulls for large sources | `databricks-spark-declarative-pipelines` skill cited; `manage_pipeline` shows `apply_changes` / Auto Loader (not full overwrite) | [ ] |
| V. CDC/Historization | Type-2 SCD in Silver, `_hist` tables in Gold | `get_table_stats_and_schema` on a Silver table shows `__START_AT` / `__END_AT`; `gold_hist.*` populated | [ ] |
| VI. Optimization | Z-ordering on filter columns, statistics computed | `execute_sql` `DESCRIBE DETAIL` shows non-empty `clusteringColumns`; `DESCRIBE HISTORY` shows recent `OPTIMIZE` | [ ] |
| VII. View Abstraction | Customers access views only, explicit columns | `manage_uc_grants` shows customer principals have `SELECT` only on `gold.v_*`, never on `gold_etl.*` | [ ] |
| VIII. Resource Attribution | Every job/pipeline/warehouse/cluster carries `product=lakeforge` and feature/owner tags | `execute_sql` on `system.lakeflow.pipelines`, `system.lakeflow.jobs`, `system.compute.warehouses`, `system.compute.clusters` shows the tag on every resource for this feature | [ ] |

## Additional Mandatory Control: Databricks Well-Architected Final Verification

| Pillar | Requirement | Verified |
|--------|-------------|----------|
| Operational Excellence | Ownership, observability, runbooks, repeatable operations, attribution | [ ] |
| Security, Privacy, and Compliance | Unity Catalog, least privilege, sensitive data controls, auditability | [ ] |
| Reliability | Bronze recovery point, replay/backfill, layer progression | [ ] |
| Performance Efficiency | Incremental processing, optimized layouts and serving | [ ] |
| Cost Optimization | Right-sized compute, cost-aware scheduling, attribution | [ ] |
| Data and AI Governance | Quality gates, lineage, ownership, failed-record handling | [ ] |
| Interoperability and Usability | Governed views, explicit contracts, usable documentation | [ ] |

---

## Acceptance Criteria Sign-Off

| Criterion | Met? | Evidence (live MCP probe + skill cited) |
|-----------|------|------------------------------------------|
| All 8 Lakehouse Principles satisfied | | Reference rows above; cite the `system.*` query result for each |
| All 7 Databricks Well-Architected pillars satisfied | | Reference the "Additional Mandatory Control: Databricks Well-Architected Final Verification" table above; cite each pillar's URL via `databricks-docs` |
| All WPs in "done" lane | | `lakeforge status` output |
| Documentation complete | | Spec, plan, tasks, WP READMEs all present |
| Quality gates operational | | `manage_uc_monitors` recent run (skill: `databricks-unity-catalog`) |
| Security (ACLs) configured | | `manage_uc_grants` (skill: `databricks-unity-catalog`) |
| Optimization applied | | `execute_sql` `DESCRIBE DETAIL` (skill: `databricks-spark-declarative-pipelines` / `databricks-dbsql`) |
| No data quality regressions | | Quarantine table row delta + monitor trend |
| Resource attribution tagged | | `system.lakeflow.*` / `system.compute.*` query result for `product=lakeforge` (Principle VIII) |

---

## Discovery (mandatory)

Before running the acceptance workflow, gather the following:

1. **Feature slug** (e.g., `005-lakehouse-feature`). If omitted, detect automatically.
2. **Acceptance mode**:
   - `pr` when the feature will merge via hosted pull request.
   - `local` when the feature will merge locally without a PR.
   - `checklist` to run the readiness checklist without committing.
3. **Validation commands executed** (tests/builds). Collect each command verbatim.
4. **Acceptance actor** (optional, defaults to the current agent name).

Ask one focused question per item and confirm the summary before continuing.

---

## Execution Plan

1. Compile the acceptance options into an argument list:
   - Always include `--actor "__AGENT__"`.
   - Append `--feature "<slug>"` when the user supplied a slug.
   - Append `--mode <mode>` (`pr`, `local`, or `checklist`).
   - Append `--test "<command>"` for each validation command provided.

2. Run `{SCRIPT}` (the CLI wrapper) with the assembled arguments **and** `--json`.

3. Parse the JSON response for:
   - `summary.ok` (boolean)
   - `summary.outstanding` categories
   - `instructions` (merge steps)
   - `cleanup_instructions`

4. Present the outcome with lakehouse-specific context.

---

## Acceptance Decision

### ✅ ACCEPT
All criteria met, lakehouse feature ready for production:
- All 8 Lakehouse Principles satisfied (incl. Resource Attribution verified via `system.lakeflow.*` / `system.compute.*`)
- All 7 Databricks Well-Architected pillars satisfied (each pillar's URL cited via `databricks-docs`)
- All WPs in "done" lane
- Documentation complete
- Quality gates operational (verified live via `manage_uc_monitors`)
- Security configured (verified live via `manage_uc_grants`)
- Optimization applied (verified live via `execute_sql` `DESCRIBE DETAIL`)

**Post-acceptance steps**:
1. Mark all WPs as "done" in kanban
2. Update feature documentation
3. Archive or close feature branch

### ❌ REJECT
Document failures, return to implementation:
- List which lakehouse principles & Databricks well-architected pillars failed
- Identify specific WPs needing rework
- Provide clear remediation steps

### ⚠️ CONDITIONAL ACCEPT
Minor issues, document for follow-up:
- Non-blocking issues that can be addressed post-merge
- Performance optimizations that can be incremental
- Documentation gaps that don't affect functionality

---

## Post-Acceptance

Upon acceptance:
1. Mark all WPs as "done" in kanban
2. Update feature documentation with final architecture
3. Archive or close feature branch
4. Update data catalog with new tables/views
5. Configure monitoring for quality gates
6. Hand off to operations team

---

## Error Handling

- If the command fails or returns invalid JSON, report the failure and request user guidance.
- When outstanding issues exist, do **not** attempt to force acceptance—return the checklist and prompt the user to fix the blockers.
- For lakehouse-specific failures, reference the 8 Lakehouse Principles (and the matching `system.*` probe in the playbook above) plus the 7 Databricks Well-Architected pillars (and the URLs returned by `databricks-docs`) for remediation guidance.
