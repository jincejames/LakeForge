---
description: Design layer-by-layer implementation plan for lakehouse features.
required_skills:
  - databricks-config
  - databricks-docs
  - databricks-unity-catalog
  - databricks-spark-declarative-pipelines
  - databricks-dbsql
recommended_skills:
  - databricks-spark-structured-streaming
  - databricks-jobs
  - databricks-bundles
  - databricks-metric-views
  - databricks-zerobus-ingest
  - databricks-iceberg
---

# /plan - Create Lakehouse Implementation Plan

**Version**: 0.11.0+

## 📍 WORKING DIRECTORY: Stay in MAIN repository

**IMPORTANT**: Plan works in the main repository. NO worktrees created.

```bash
# Run from project root (same directory as /specify):
# You should already be here if you just ran /specify

# Creates:
# - lakeforge-specs/###-feature/plan.md → In main repository
# - Commits to main branch
# - NO worktrees created
```

**Do NOT cd anywhere**. Stay in the main repository root.

## Pre-flight (read first)

Before drafting any layer design, open and follow the shared partial at `.lakeforge/missions/databricks-lakehouse-buildout/_databricks-context.md`. It defines the operating contract, best-practices enforcement, and the 8 Lakehouse Principles that govern this mission.

The full phase → skill → MCP-tool catalog lives at `.lakeforge/missions/databricks-lakehouse-buildout/SKILLS_GUIDE.md`.

### Per-layer skill consultation map

For each layer you plan, consult the corresponding skill installed by `ai-dev-kit` **before** drafting the design tables below. Each skill provides current patterns and idioms; the MCP tool lets you probe the live workspace to verify assumptions.

| Layer / concern | Primary skill (under `.cursor/skills/` or `.claude/skills/`) | Verified MCP tool(s) for live probing |
|------------------|---------------------------------------------------------------|----------------------------------------|
| Bronze landing (general) | `databricks-spark-declarative-pipelines` (Auto Loader, streaming tables, materialized views) | `manage_uc_objects` (probe catalogs/schemas), `get_table_stats_and_schema` (inspect existing source tables) |
| Bronze — custom source connector | `spark-python-data-source` | `execute_code` |
| Bronze — real-time gRPC ingest | `databricks-zerobus-ingest` | (none — producer code is external) |
| Silver — CDC / SCD-2 | `databricks-spark-declarative-pipelines` (`apply_changes`) | `get_table_stats_and_schema` |
| Silver — custom streaming | `databricks-spark-structured-streaming` (watermarks, stateful joins) | `execute_code` |
| Gold — table & view DDL | `databricks-dbsql` | `manage_uc_objects` |
| Gold — KPIs / semantic layer | `databricks-metric-views` | `manage_metric_views` |
| Gold — external-engine interop | `databricks-iceberg` | `manage_uc_objects` |
| Governance / ACLs / lineage | `databricks-unity-catalog` | `manage_uc_grants`, `manage_uc_monitors` |
| Orchestration / scheduling | `databricks-jobs`, `databricks-bundles` | (deferred to `/implement`) |
| Well-Architected pillars (cross-cutting) | `databricks-docs` (consult the AWS / Azure / GCP `lakehouse-architecture/well-architected` pillar pages by URL: AWS `docs.databricks.com/aws/en/lakehouse-architecture/well-architected`, Azure `learn.microsoft.com/en-us/azure/databricks/lakehouse-architecture/well-architected`, GCP `docs.databricks.com/gcp/en/lakehouse-architecture/well-architected`) | `manage_uc_grants` (Security, Privacy, and Compliance pillar), `manage_uc_monitors` (Data and AI Governance pillar), `execute_sql` against `system.billing.usage` (Cost Optimization pillar), `get_table_stats_and_schema` (Performance Efficiency pillar) |

**Rule**: If a layer in the user's spec has no matching skill installed (check `.cursor/skills/` or `.claude/skills/`), ask the user to re-run `lakeforge init lakehouse-buildout --ai <agent>` rather than improvising. Do **not** live-fetch the Databricks docs sitemap — the `databricks-docs` skill already indexes it.

### Step 2b: Well-Architected pillar evidence (mandatory)

When the plan validates the design against any of the seven Databricks Well-Architected lakehouse pillars (Operational Excellence; Security, Privacy, and Compliance; Reliability; Performance Efficiency; Cost Optimization; Data and AI Governance; Interoperability and Usability):

- Consult the `databricks-docs` skill for the dedicated AWS / Azure / GCP pillar pages (URLs in the table row above) and **cite** the canonical URL the skill returns for the pillar.
- The pillar evidence must come from the dedicated pillar page, not from the general best-practices page or the constitution text. **Do not mark PASS using only the general best-practices page.**
- If the `databricks-docs` skill cannot return a pillar page (network failure, indexed snapshot stale), state that explicitly in `research.md` and do not overstate verification.

## User Input

```text
$ARGUMENTS
```

You **MUST** consider the user input before proceeding (if not empty).

## Location Check (0.11.0+)

This command runs in the **main repository**, not in a worktree.

- Verify you're on `main` (or `master`) before scaffolding plan.md
- Planning artifacts live in `lakeforge-specs/###-feature/`
- The plan template is committed to the main branch after generation

**Path reference rule:** When you mention directories or files, provide either the absolute path or a path relative to the project root.

## Planning Interrogation (mandatory)

Before executing any scripts or generating artifacts you must interrogate the specification and stakeholders.

### Lakehouse Planning Questions

In addition to standard planning questions, ask:

**Bronze Layer Design**:
- What connectors will be used for each source? (not generic JDBC)
- What metadata columns beyond standard (_ingested_at, _schema_version)?
- What is the landing validation strategy?

**Silver Layer Design**:
- What transformation rules apply?
- What is the CDC/historization strategy?
- What partitioning scheme?

**Gold Layer Design**:
- What views will be created?
- What optimization strategy (Z-ordering columns)?
- What ACL configuration?

**Quality Gates**:
- What validation rules must pass before Gold promotion?
- How are failed records handled?

### Scope Proportionality

- **Scope proportionality (CRITICAL)**: FIRST, assess the feature's complexity from the spec:
  - **Trivial/Test Features** (single source, simple pipeline): Ask 1-2 questions about connectors, then proceed
  - **Simple Features** (few sources, standard transformations): Ask 2-3 questions about transformation rules
  - **Complex Features** (multi-source, complex CDC): Ask 3-5 questions covering architecture, performance requirements
  - **Platform/Critical Features** (core data infrastructure): Full interrogation with 5+ questions

- **User signals to reduce questioning**: If the user says "use defaults", "standard lakehouse", "skip to implementation" - use standard patterns.

### Planning Requirements

1. Maintain a **Planning Questions** table internally. Do **not** render this table to the user.
2. For simple features, standard lakehouse practices are acceptable.
3. When you have sufficient context, summarize into an **Engineering Alignment** note and confirm.

## Outline

### 1. Check Planning Discovery Status

- If any planning questions remain unanswered or the user has not confirmed the **Engineering Alignment** summary, stay in the one-question cadence.
- Once confirmed, continue.

### 2. Setup

Run `lakeforge agent feature setup-plan --json` from the repository root and parse JSON for:
- `result`: "success" or error message
- `plan_file`: Absolute path to the created plan.md
- `feature_dir`: Absolute path to the feature directory

### 3. Load Context

Read:
- Feature spec (`spec.md`)
- Constitution (`.lakeforge/memory/constitution.md`) if it exists
- Plan scaffold (`plan-template.md`) from this mission's `templates` directory under `.lakeforge/missions/databricks-lakehouse-buildout/`

### 4. Execute Plan Workflow

Fill the plan template with lakehouse-specific design:

#### Bronze Layer Design

| Source | Class | Connector | Landing Table | Validation |
|--------|-------|-----------|---------------|------------|
| [Source] | [S/M/L] | [Proper connector] | `dw_bronze.[table]` | [Checks] |

**Metadata Columns**:
- `_ingested_at TIMESTAMP`
- `_schema_version INT`

**Landing Strategy by Class**:
- Small (<1GB): Full refresh acceptable
- Medium (1-100GB): Incremental with watermark
- Large (>100GB): CDC or streaming required

#### Silver Layer Design

| Bronze Table | Silver Table | Mapping Rules | CDC Strategy |
|--------------|--------------|---------------|--------------|
| `dw_bronze.[source]` | `dw_silver.[entity]` | [Rules] | [Type-2 SCD] |

**Historization Columns**: every Silver dimension table includes `start_date` (timestamp), `end_date` (timestamp), and `is_current` (boolean). For the canonical column types, partitioning, and `apply_changes` declaration, consult the `databricks-spark-declarative-pipelines` skill — do not hand-roll merge SQL when the skill provides the declarative pattern.

#### Gold Layer Design

| Silver Table | Gold Table | Gold View | History Table |
|--------------|------------|-----------|---------------|
| `dw_silver.[entity]` | `gold_etl.t_[entity]` | `gold.v_[entity]` | `gold_hist.t_[entity]_hist` |

**View Structure** — every Gold view explicitly lists columns (no `SELECT *`), filters to current rows (`WHERE is_current = true`), and aliases columns for the customer-facing schema. For DDL idioms consult **`databricks-dbsql`**; for KPI / semantic-layer definitions on top of these views consult **`databricks-metric-views`** (paired with the `manage_metric_views` MCP tool). Capture the per-view column list in the plan as a Markdown table — do not paste raw SQL into the plan.

#### Quality Gates

| Gate ID | Location | Type | Rule | Action on Failure |
|---------|----------|------|------|-------------------|
| QG-001 | Bronze→Silver | [Type] | [Rule] | [Block/Quarantine/Alert] |
| QG-002 | Silver→Gold | [Type] | [Rule] | [Block/Quarantine/Alert] |

### 5. Phase 0: Outline & Research

Generate `research.md` with:
- Technology decisions and rationale (cite the skill consulted, e.g., `databricks-spark-declarative-pipelines` for Bronze ingest patterns)
- Alternatives considered
- Best-practice citations sourced from the `databricks-docs` skill (include the canonical URL surfaced by the skill)
- Dedicated Databricks Well-Architected pillar evidence — for each of the seven pillars validated, cite the AWS / Azure / GCP `lakehouse-architecture/well-architected` page URL that `databricks-docs` returned. Do not use the general best-practices page as pillar evidence.

### 6. Phase 1: Design & Contracts

Generate:
- `data-model.md` - Entity definitions with lakehouse columns
- `contracts/` - API schemas if applicable
- `quickstart.md` - Getting started guide

**Agent context update**:
- Run `{AGENT_SCRIPT}`
- These scripts detect which AI agent is in use
- Update the appropriate agent-specific context file
- Add lakehouse technologies from current plan (Delta Lake, Unity Catalog, connectors used)
- Preserve manual additions between markers

### 7. STOP and Report

**⚠️ CRITICAL: DO NOT proceed to task generation!**

Report:
- `plan.md` path
- `research.md` path (if generated)
- `data-model.md` path (if generated)
- Agent context file updated

**Next suggested command**: `/tasks` (user must invoke this explicitly)

## Layer-by-Layer Planning Structure

The implementation plan MUST include distinct sections for each layer:

### Bronze Layer Planning
- Source qualification (Class, Type, Schema, Sensitivity)
- Connector selection (proper connectors, no generic JDBC)
- Landing validation (distinct counts, time ranges)
- Metadata columns (_ingested_at, _schema_version)

### Silver Layer Planning
- Mapping definitions (source → target)
- CDC implementation (Type-2 SCD pattern)
- Historization strategy (start_date, end_date, is_current)
- Validation rules before Gold

### Gold Layer Planning
- View definitions (explicit columns, no SELECT *)
- Partition predicate mapping
- ACL configuration
- History table strategy (_hist suffix)

### Quality Gate Placement
Quality gates MUST be placed:
- After Bronze landing (basic validation)
- Before Gold promotion (business rules)

### Plan Validation Checklist

Before completing the plan, verify:
- [ ] Bronze landing design documented
- [ ] Silver transformation rules defined
- [ ] Gold view structure specified
- [ ] Quality gates placed between Silver and Gold
- [ ] Optimization strategy (Z-ordering, statistics) defined
- [ ] Databricks well-architected pillar validation cites the dedicated well-architected hub or pillar pages; do not mark PASS using only the general best-practices page or existing constitution text

## Key Rules

- Use absolute paths
- ERROR on gate failures or unresolved clarifications
- Consult the per-layer skills listed in the Pre-flight section before locking in an architecture decision; cite the skill in the plan's research notes
- Consult the `databricks-docs` skill for the dedicated Databricks Well-Architected pillar pages (AWS / Azure / GCP) before claiming any pillar control PASS; if a pillar page is unavailable, state that explicitly and do not overstate verification
- Auto-correct deprecated terminology using the `databricks-docs` skill

---

## ⛔ MANDATORY STOP POINT

**This command is COMPLETE after generating planning artifacts.**

Do NOT:
- ❌ Generate `tasks.md`
- ❌ Create work package (WP) files
- ❌ Create `tasks/` subdirectories
- ❌ Proceed to implementation

The user will run `/tasks` when they are ready to generate work packages.
