# Lakehouse Buildout — Pre-flight Context (shared partial)

**This is a partial.** It is not a command. Files prefixed with `_` are documentation that the lakehouse-buildout commands (`/specify`, `/plan`, `/tasks`, `/implement`, `/review`, `/accept`) reference instead of duplicating.

> **Agents: read this whole file before doing anything else when a lakehouse-buildout command starts.**

---

## 1. Pre-flight checklist

Before answering the user's request:

1. **Verify workspace context** — consult the `databricks-config` skill, or call the `manage_workspace` MCP tool, to confirm the active Databricks profile/host. If no host is configured, surface that to the user immediately rather than guessing.
2. **Open `SKILLS_GUIDE.md`** at `.lakeforge/missions/databricks-lakehouse-buildout/SKILLS_GUIDE.md` for the canonical phase → skill → MCP-tool mapping. Use it to pick which skills to consult for the user's request.
3. **Load the constitution** at `.lakeforge/memory/constitution.md` if it exists. Treat its principles as authoritative; the 8 Lakehouse Principles below act as defaults when the constitution is silent.

---

## 2. Documentation lookup rules

- **DO** consult the `databricks-docs` skill for terminology, current feature names ("DLT" → "Lakeflow Declarative Pipelines"), and canonical doc URLs to cite.
- **DO** consult topic-specific skills (e.g., `databricks-spark-declarative-pipelines`, `databricks-unity-catalog`, `databricks-jobs`) for patterns and code shapes.
- **DO NOT** live-fetch the public Databricks docs sitemap. The `databricks-docs` skill already indexes it; live-fetching is slow, fragile, and can return stale/cached results.
- **If a needed skill is not installed**, ask the user to re-run `lakeforge init lakehouse-buildout --ai <agent>` (or bump `ai_dev_kit.version` in `.lakeforge/config.yaml`) — do not improvise.

---

## 3. Best-Practices Enforcement (STRICT)

This mission enforces strict adherence to documented Databricks best practices throughout **every** phase. Templates that reference this partial inherit these rules.

**Rules**:

1. **Never propose, plan, task, implement, or accept patterns that contradict documented best practices.** Examples that are always non-compliant:
   - DBFS for production data
   - Generic JDBC for sources that have a specialized connector (Salesforce, SAP, …)
   - Skipping Bronze (writing user data directly to Silver/Gold)
   - `SELECT *` in Gold views
   - Quality-gate-free promotion from Silver to Gold
   - Type-1 SCD overwrite where Type-2 historization is appropriate
   - Auto-optimize on tables with explicit Z-ordering
2. **When the user describes a non-compliant approach** (in any phase): refuse the non-compliant pattern, explain why with a doc citation (via `databricks-docs`), and offer the best-practice alternative.
3. **Discovery / planning questions must only suggest best-practice options.**
   - Good: "Which native connector will you use for Salesforce data?"
   - Bad: "Will you use generic JDBC or a specialized connector?"

**Example enforcement**:

> User: "I want to land data directly in Silver to save time."
> Agent: "I cannot proceed with direct Silver landing. Bronze-first is required (per `databricks-spark-declarative-pipelines` and the constitution Principle I). Let me design a streamlined Bronze landing that meets your speed goal while preserving the audit trail."

---

## 4. The 8 Lakehouse Principles (one-line reminders)

Full per-principle red-flag checklists live in `command-templates/review.md` and `command-templates/accept.md`. The following one-liners are the **always-on** invariants every command must respect.

| # | Principle | One-line invariant |
|---|-----------|--------------------|
| I | Bronze-First Data Landing | Every external source lands in Bronze first, untransformed, with `_ingested_at` and `_schema_version`. |
| II | Layer Separation and Progression | Data flows Bronze → Silver → Gold; no skipping. |
| III | Data Quality Gates (NON-NEGOTIABLE) | Validation gates exist before Gold; failed records go to a quarantine table, never silently dropped. |
| IV | Incremental Ingestion Strategy | Sources >1 GB use incremental/CDC patterns, never full pulls. |
| V | CDC and Historization | Type-2 SCD in Silver (`start_date`, `end_date`, `is_current`); paired `_hist` tables in Gold. |
| VI | Optimization and Compaction | Z-order on filter columns, statistics computed; auto-optimize OFF on Z-ordered tables. |
| VII | View Abstraction Layer | Customers consume Gold via views with explicit columns; no `SELECT *`, no direct table grants. |
| VIII | Resource Provenance and Attribution | Every job, pipeline, warehouse, and cluster carries `product=lakeforge` plus feature/owner tags; Python entry points register the SDK user-agent extra. Failure is a review/accept blocker. |

---

## 5. Skill consultation contract

For **every** lakehouse-buildout command:

1. **Skill consultation is the first step**, before writing prose, code, or SQL. Open the relevant skill's `SKILL.md` (under `.cursor/skills/<name>/` or `.claude/skills/<name>/`) and read its trigger keywords + examples.
2. **Prefer MCP tools over shell-CLI** when both exist — MCP returns structured JSON and respects the active workspace.
3. **Cite the skill** in your reply so the user can audit (e.g., "Per `databricks-spark-declarative-pipelines`, …").
4. **Do not re-fetch** the public Databricks docs sitemap. The `databricks-docs` skill already indexes it.
5. **If a required skill is missing**, ask the user to re-run `lakeforge init lakehouse-buildout --ai <agent>` — do not improvise.

---

## 6. Cross-references

- **`SKILLS_GUIDE.md`** (this directory) — phase → skill → MCP-tool mapping, full skill catalog, replacement guide for old WebFetch patterns.
- **`.lakeforge/memory/constitution.md`** — project-specific principles (optional; overrides defaults here when present).
- **`command-templates/`** (this directory) — the per-phase command logic that references this partial.
- **`templates/`** (this directory) — document scaffolds (`spec-template.md`, `plan-template.md`, `tasks-template.md`).
- **`mission.yaml`** (this directory) — mission metadata (artifacts, validators, agent context).
