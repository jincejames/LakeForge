# Lakehouse Buildout — Skills & MCP Reference Guide

**Audience**: AI coding agents (Cursor, Claude Code, Copilot, Codex, Gemini) and humans working on this project.
**Purpose**: This is the **single source of truth** for which `ai-dev-kit` skill or MCP tool to consult during each phase of the lakehouse buildout. The lakehouse-buildout command templates (`/specify`, `/plan`, `/tasks`, `/implement`, `/review`, `/accept`) reference the skill names defined here verbatim.
**Replaces**: Ad-hoc live-fetching of the public Databricks docs sitemap. Use the `databricks-docs` skill instead.

---

## How this fits with `ai-dev-kit`

When `lakeforge init lakehouse-buildout --ai <agent>` runs, it delegates to [`ai-dev-kit`](https://github.com/databricks-solutions/ai-dev-kit)'s `install.sh` with `--skills-profile data-engineer`. That installer:

1. Clones `ai-dev-kit` into `~/.ai-dev-kit/repo/` (global cache, shared across projects).
2. Creates a Python venv at `~/.ai-dev-kit/.venv/` and installs the `databricks-mcp-server` package.
3. Copies the **14 skills** of the `data-engineer` profile into your project under each agent's auto-discovery directory:
   - Cursor → `.cursor/skills/<skill-name>/SKILL.md`
   - Claude Code → `.claude/skills/<skill-name>/SKILL.md`
   - GitHub Copilot → `.github/skills/<skill-name>/SKILL.md`
   - Codex → `.codex/skills/<skill-name>/SKILL.md`
   - Gemini → `.gemini/skills/<skill-name>/SKILL.md`
   - **Note:** When both `cursor` and `claude` are selected, the installer writes only `.claude/skills/` and Cursor reads from there.
4. Writes/merges an MCP server entry pointing at `~/.ai-dev-kit/repo/databricks-mcp-server/run_server.py` into each agent's MCP config (`.cursor/mcp.json`, `.mcp.json`, etc.).

**Verify your install** at any time:

```bash
ls .cursor/skills/ 2>/dev/null || ls .claude/skills/   # 14 directories
cat .cursor/mcp.json | grep -A2 databricks              # MCP entry
cat .ai-dev-kit/install-metadata.json                   # version, agents, profile
```

The pinned `ai-dev-kit` version is recorded in `.lakeforge/config.yaml` under `ai_dev_kit.version`. Bump it there to upgrade.

---

## Quick decision matrix — Phase → Skills → MCP tools

Use this table when you're not sure where to start. Click the skill name in the section below for trigger keywords and examples.

| Lakeforge phase | Primary skill(s) | Secondary skill(s) | Verified MCP tools |
|------------------|---------------------|---------------------|------------------------|
| `/specify` (discovery) | `databricks-docs` | `databricks-config` | `manage_workspace`, `get_current_user`, `manage_warehouse` |
| `/plan` — Bronze | `databricks-spark-declarative-pipelines`, `databricks-unity-catalog` | `spark-python-data-source`, `databricks-zerobus-ingest` | `manage_uc_objects`, `get_table_stats_and_schema` |
| `/plan` — Silver (CDC/SCD-2) | `databricks-spark-declarative-pipelines` | `databricks-spark-structured-streaming` | `get_table_stats_and_schema` |
| `/plan` — Gold | `databricks-metric-views`, `databricks-dbsql` | `databricks-iceberg` | `manage_uc_objects` |
| `/plan` — Orchestration | `databricks-jobs`, `databricks-bundles` | — | (none at planning time) |
| `/tasks` | (inherited from `/plan`) | `databricks-synthetic-data-gen` (test-data WPs) | (none) |
| `/implement` — Bronze | `databricks-spark-declarative-pipelines` | `databricks-python-sdk` | `manage_uc_objects` (CREATE CATALOG/SCHEMA), `manage_pipeline` (create/update SDP), `execute_sql` (CREATE TABLE), `execute_code` (Python ingestion) |
| `/implement` — Silver | `databricks-spark-declarative-pipelines`, `databricks-spark-structured-streaming` | — | `execute_sql` (MERGE/CDC), `manage_pipeline` (SDP CDC), `execute_code` |
| `/implement` — Gold | `databricks-metric-views`, `databricks-dbsql` | — | `execute_sql` (CREATE VIEW), `manage_metric_views`, `manage_uc_grants` (ACLs), `get_table_stats_and_schema` |
| `/implement` — Deploy | `databricks-jobs`, `databricks-bundles` | — | `manage_jobs`, `manage_job_runs` (bundles deploy via `databricks bundle deploy` CLI) |
| `/review` | (mirror of `/implement`) | — | `execute_sql` (re-run validation), `get_table_stats_and_schema`, `manage_uc_monitors` |
| `/accept` | `databricks-unity-catalog` (audit/lineage via system tables) | — | `execute_sql` against `system.access.*` and `system.lakeflow.*`, `manage_uc_monitors` |

---

## Skill catalog — `data-engineer` profile (14 skills)

Each entry below uses this format:

> **Trigger keywords** — what makes the agent reach for this skill.
> **When to use** — the lakehouse contexts where it applies.
> **MCP pairing** — the verified MCP tool(s) to call alongside.

### Core skills (always installed)

#### `databricks-config`
> **Trigger keywords**: workspace, profile, `~/.databrickscfg`, host, OAuth, DEFAULT profile, `databricks auth`.
> **When to use**: confirming the active workspace at the start of any session; switching profiles; debugging "no host configured" errors.
> **MCP pairing**: `manage_workspace`, `get_current_user`.

#### `databricks-docs`
> **Trigger keywords**: documentation, latest feature name, deprecated term, "what's the official name for", "is this still supported".
> **When to use**: verifying terminology before answering ("DLT" → "Lakeflow Declarative Pipelines"); finding canonical doc URLs to cite. **Use this in place of any ad-hoc live-fetch of the public Databricks docs sitemap.**
> **MCP pairing**: none — this is a documentation skill.

#### `databricks-python-sdk`
> **Trigger keywords**: `databricks-sdk`, `WorkspaceClient`, `databricks-connect`, CLI, REST API patterns, retries, pagination.
> **When to use**: writing helper scripts that call the Databricks REST API; using `databricks-connect` for local Spark dev against a remote cluster; replacing brittle `requests` code with the SDK.
> **MCP pairing**: most MCP tools wrap the SDK — prefer the MCP tool when it exists.

#### `databricks-unity-catalog`
> **Trigger keywords**: catalog, schema, volume, grant, external location, storage credential, lineage, system tables, `system.access`, `system.lakeflow`, row/column mask, monitor.
> **When to use**: any DDL on catalogs/schemas/volumes; ACL design (`/implement` Gold, `/accept` audit); lineage checks during `/review`.
> **MCP pairing**: `manage_uc_objects`, `manage_uc_grants`, `manage_uc_storage`, `manage_uc_connections`, `manage_uc_tags`, `manage_uc_security_policies`, `manage_uc_monitors`, `manage_uc_sharing`.

### `data-engineer` profile skills

#### `databricks-spark-declarative-pipelines`
> **Trigger keywords**: SDP, LDP, Lakeflow Declarative Pipelines, streaming table, materialized view, Auto Loader, `@dlt.table`, `apply_changes`, SCD Type 1, SCD Type 2, CDC.
> **When to use**: most Bronze landing logic, all Silver CDC/SCD-2, every materialized-view definition. **This is the workhorse skill for `/implement` Bronze and Silver.**
> **MCP pairing**: `manage_pipeline`, `manage_pipeline_run`.

#### `databricks-spark-structured-streaming`
> **Trigger keywords**: `readStream`, `writeStream`, watermark, checkpoint, stateful aggregation, Kafka, foreachBatch, trigger interval.
> **When to use**: when SDP isn't enough — custom streaming logic, stateful joins, complex watermarks, raw Kafka consumers.
> **MCP pairing**: `execute_code` (run on a cluster), `manage_cluster`.

#### `databricks-jobs`
> **Trigger keywords**: job, task, multi-task, schedule, dependency, retry, cluster reuse, parameters, notification.
> **When to use**: orchestrating multi-step pipelines (e.g., land Bronze → run Silver → publish Gold) once `/implement` is complete.
> **MCP pairing**: `manage_jobs`, `manage_job_runs`.

#### `databricks-bundles`
> **Trigger keywords**: Asset Bundles, DABs, `databricks.yml`, `bundle deploy`, `bundle validate`, `bundle run`, environments (dev/staging/prod), CI/CD.
> **When to use**: producing the bundle YAML so CI/CD can deploy the project; promoting from dev to prod.
> **MCP pairing**: none — bundles deploy via the `databricks bundle deploy` CLI (run via shell).

#### `databricks-dbsql`
> **Trigger keywords**: SQL warehouse, serverless SQL, query optimization for warehouses, photon, materialized view in DBSQL, `EXPLAIN`, query history.
> **When to use**: tuning Gold-layer customer-facing queries; sizing warehouses; writing performant analytical SQL.
> **MCP pairing**: `execute_sql`, `execute_sql_multi`, `manage_warehouse`, `get_table_stats_and_schema`.

#### `databricks-iceberg`
> **Trigger keywords**: Iceberg, managed Iceberg, external Iceberg, UniForm, Snowflake interop, REST catalog.
> **When to use**: when Gold tables must be readable by external engines (Snowflake, Trino, …) without copy.
> **MCP pairing**: `manage_uc_objects`, `execute_sql`.

#### `databricks-zerobus-ingest`
> **Trigger keywords**: Zerobus, gRPC, real-time event ingest, IoT producer, low-latency push.
> **When to use**: a source pushes events directly (sub-second SLA) instead of being polled — typically rare.
> **MCP pairing**: `execute_code` (producer code lives outside Databricks).

#### `spark-python-data-source`
> **Trigger keywords**: custom DataSource, `pyspark.sql.datasource`, `DataSourceReader`, `DataSourceWriter`, partitioning a custom source.
> **When to use**: source has no Spark connector and no SaaS-style ingestion path — write a Python DataSource.
> **MCP pairing**: `execute_code`.

#### `databricks-metric-views`
> **Trigger keywords**: metric view, KPI, semantic layer, `CREATE METRIC VIEW`, dimensions, measures, certified metric.
> **When to use**: defining business metrics over Gold tables so dashboards/Genie reuse them.
> **MCP pairing**: `manage_metric_views`, `execute_sql`.

#### `databricks-synthetic-data-gen`
> **Trigger keywords**: Faker, synthetic data, test fixture, generated dataset, dbldatagen.
> **When to use**: building test-data WPs (`/tasks`) or seeding dev/staging environments.
> **MCP pairing**: `execute_code`.

---

## MCP tool quick reference

These tool names match the actual `databricks-mcp-server` source (`databricks_mcp_server/tools/*.py`). Call them through the MCP server registered during `lakeforge init`.

### Workspace / identity

- **`manage_workspace`** — list/select Databricks profile, validate auth, OAuth login.
- **`get_current_user`** — return the active user/principal.

### SQL & introspection

- **`execute_sql`** — run a single SQL statement against a SQL warehouse.
- **`execute_sql_multi`** — run several SQL statements in one batch.
- **`manage_warehouse`** — list/start/stop SQL warehouses.
- **`get_table_stats_and_schema`** — describe a table (columns, types, row count, size).
- **`get_volume_folder_details`** — list a UC volume folder.

### Compute

- **`execute_code`** — run Python on a cluster (use sparingly; prefer SDP).
- **`manage_cluster`** — list/start/stop clusters.
- **`list_compute`** — enumerate clusters, warehouses, and serverless compute.

### Unity Catalog

- **`manage_uc_objects`** — catalogs, schemas, tables, volumes (create / get / list / delete).
- **`manage_uc_grants`** — grants on UC objects.
- **`manage_uc_storage`** — external locations and storage credentials.
- **`manage_uc_connections`** — UC foreign connections.
- **`manage_uc_tags`** — tags on UC objects.
- **`manage_uc_security_policies`** — row filters and column masks.
- **`manage_uc_monitors`** — Lakehouse Monitoring (data-quality monitors).
- **`manage_uc_sharing`** — Delta Sharing recipients/shares.
- **`manage_metric_views`** — metric view CRUD.

### Pipelines & jobs

- **`manage_pipeline`** — create/update/delete SDP / Lakeflow pipelines.
- **`manage_pipeline_run`** — trigger and inspect pipeline runs.
- **`manage_jobs`** — multi-task workflow CRUD.
- **`manage_job_runs`** — trigger and inspect job runs.

### Files

- **`manage_volume_files`** — UC volume file ops.
- **`manage_workspace_files`** — workspace files (notebooks, scripts).

> Out-of-scope for `data-engineer` (installed only with other profiles): Vector Search, Serving, Lakebase, Genie, AIBI Dashboards, Agent Bricks, PDF generation. They're listed in the MCP server but the `databricks-` skills behind them are not in the `data-engineer` profile.

---

## Replacement guide — old patterns → new patterns

| Old pattern (Phase 1 or earlier) | New pattern (Phase 2) |
|----------------------------------|--------------------------|
| Live-fetching the Databricks docs sitemap | Consult the **`databricks-docs`** skill. |
| Live-fetching the Databricks best-practices pages | Consult **`databricks-docs`**, then the topic-specific skill (e.g., `databricks-spark-declarative-pipelines`). |
| Inline SQL example for SCD-2 / `start_date / end_date / is_current` | Reference **`databricks-spark-declarative-pipelines`** + `apply_changes` (Lakeflow handles SCD-2 declaratively). |
| Inline `CREATE OR REPLACE VIEW gold.v_*` example | Reference **`databricks-dbsql`** for view DDL and **`databricks-metric-views`** for KPI semantics. |
| Free-text "use proper connectors not generic JDBC" | Reference **`databricks-spark-declarative-pipelines`** (Auto Loader) or **`databricks-zerobus-ingest`** depending on source type. |
| Manual call to `databricks-cli sql query` | Use **`execute_sql`** MCP tool. |
| Manual `DESCRIBE TABLE` parsing | Use **`get_table_stats_and_schema`** MCP tool. |
| Hand-written job JSON | Use **`databricks-jobs`** skill + **`manage_jobs`** MCP tool, or **`databricks-bundles`** for git-checked-in deployment. |

---

## Agent operating contract

When following any lakehouse-buildout command template:

1. **Skill consultation is the first step**, before writing prose, code, or SQL. Open the skill's `SKILL.md` (in `.cursor/skills/<name>/` or `.claude/skills/<name>/`) and read the trigger keywords + examples.
2. **Prefer MCP tools over shell-CLI** when both exist — MCP returns structured JSON and respects the active workspace.
3. **Cite the skill** in your reply so the user can audit (e.g., "Per `databricks-spark-declarative-pipelines`, …").
4. **Do not re-fetch** the public Databricks docs sitemap. The `databricks-docs` skill already indexes it.
5. **If a required skill is missing**, ask the user to re-run `lakeforge init lakehouse-buildout --ai <agent>` (or upgrade `ai_dev_kit.version` in `.lakeforge/config.yaml`) — do not improvise.

---

## Updating skills / pinning a new version

```yaml
ai_dev_kit:
  version: "v0.1.10"        # bump to upgrade
  agents: ["cursor"]
  skills_profile: "data-engineer"
```

After editing `.lakeforge/config.yaml`, re-run:

```bash
lakeforge init lakehouse-buildout --ai cursor   # idempotent; reinstalls at the new tag
```

The installer's metadata file `.ai-dev-kit/install-metadata.json` records what was actually installed (tag, profile, agents, timestamp).

---

## Where to get more detail

- This guide → **what to use, when**.
- Each `SKILL.md` → **how to use it** (full examples, trade-offs).
- `.lakeforge/missions/databricks-lakehouse-buildout/command-templates/` → **lakeforge phase logic** that references skills here.
- `docs/reference/configuration.md` (lakeforge) → **integration mechanics** (versioning, gitignore, metadata).
- `https://github.com/databricks-solutions/ai-dev-kit` → upstream skill source.
