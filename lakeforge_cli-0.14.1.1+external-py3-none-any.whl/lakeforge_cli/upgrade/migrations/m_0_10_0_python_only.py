"""Migration: Remove bash scripts and update templates to use Python CLI."""

from __future__ import annotations

import re
import shutil
from pathlib import Path
from typing import Dict, List, Tuple

from ..registry import MigrationRegistry
from .base import BaseMigration, MigrationResult


@MigrationRegistry.register
class PythonOnlyMigration(BaseMigration):
    """Migrate from bash scripts to Python-only CLI commands.

    As of v0.10.0, all lakeforge commands are available through the
    `lakeforge agent` CLI namespace. Bash wrapper scripts in
    `.lakeforge/scripts/bash/` are replaced with Python implementations.

    This migration:
    1. Detects and removes bash scripts from .lakeforge/scripts/bash/
    2. Updates slash command templates to use `lakeforge agent` commands
    3. Cleans up bash scripts in worktrees
    4. Detects custom modifications and warns users
    5. Is idempotent (safe to run multiple times)
    """

    migration_id = "0.10.0_python_only"
    description = "Remove bash scripts and update templates to use Python CLI"
    target_version = "0.10.0"

    # Bash scripts that should be removed (package scripts only)
    PACKAGE_SCRIPTS = (
        "common.sh",
        "create-new-feature.sh",
        "check-prerequisites.sh",
        "setup-plan.sh",
        "update-agent-context.sh",
        "accept-feature.sh",
        "merge-feature.sh",
        "tasks-move-to-lane.sh",
        "tasks-list-lanes.sh",
        "mark-task-status.sh",
        "tasks-add-history-entry.sh",
        "tasks-rollback-move.sh",
        "validate-task-workflow.sh",
        "move-task-to-doing.sh",
    )

    # Bash → Python command mappings for template updates
    COMMAND_REPLACEMENTS = {
        # Feature management
        r"\.lakeforge/scripts/bash/create-new-feature\.sh": "lakeforge agent create-feature",
        r"scripts/bash/create-new-feature\.sh": "lakeforge agent create-feature",
        r"\.lakeforge/scripts/bash/check-prerequisites\.sh": "lakeforge agent check-prerequisites",
        r"scripts/bash/check-prerequisites\.sh": "lakeforge agent check-prerequisites",
        r"\.lakeforge/scripts/bash/setup-plan\.sh": "lakeforge agent setup-plan",
        r"scripts/bash/setup-plan\.sh": "lakeforge agent setup-plan",
        r"\.lakeforge/scripts/bash/update-agent-context\.sh": "lakeforge agent update-context",
        r"scripts/bash/update-agent-context\.sh": "lakeforge agent update-context",
        r"\.lakeforge/scripts/bash/accept-feature\.sh": "lakeforge agent feature accept",
        r"scripts/bash/accept-feature\.sh": "lakeforge agent feature accept",
        r"\.lakeforge/scripts/bash/merge-feature\.sh": "lakeforge agent feature merge",
        r"scripts/bash/merge-feature\.sh": "lakeforge agent feature merge",

        # Task workflow
        r"\.lakeforge/scripts/bash/tasks-move-to-lane\.sh": "lakeforge agent move-task",
        r"scripts/bash/tasks-move-to-lane\.sh": "lakeforge agent move-task",
        r"\.lakeforge/scripts/bash/tasks-list-lanes\.sh": "lakeforge agent list-tasks",
        r"scripts/bash/tasks-list-lanes\.sh": "lakeforge agent list-tasks",
        r"\.lakeforge/scripts/bash/mark-task-status\.sh": "lakeforge agent mark-status",
        r"scripts/bash/mark-task-status\.sh": "lakeforge agent mark-status",
        r"\.lakeforge/scripts/bash/tasks-add-history-entry\.sh": "lakeforge agent add-history",
        r"scripts/bash/tasks-add-history-entry\.sh": "lakeforge agent add-history",
        r"\.lakeforge/scripts/bash/tasks-rollback-move\.sh": "lakeforge agent rollback-move",
        r"scripts/bash/tasks-rollback-move\.sh": "lakeforge agent rollback-move",
        r"\.lakeforge/scripts/bash/validate-task-workflow\.sh": "lakeforge agent validate-workflow",
        r"scripts/bash/validate-task-workflow\.sh": "lakeforge agent validate-workflow",
        r"\.lakeforge/scripts/bash/move-task-to-doing\.sh": "lakeforge agent move-task",
        r"scripts/bash/move-task-to-doing\.sh": "lakeforge agent move-task",

        # Legacy tasks_cli.py references
        r"tasks_cli\.py move": "lakeforge agent move-task",
        r"tasks_cli\.py list": "lakeforge agent list-tasks",
        r"tasks_cli\.py mark": "lakeforge agent mark-status",
        r"tasks_cli\.py history": "lakeforge agent add-history",
        r"tasks_cli\.py rollback": "lakeforge agent rollback-move",
        r"tasks_cli\.py validate": "lakeforge agent validate-workflow",
    }

    def detect(self, project_path: Path) -> bool:
        """Check if bash scripts still exist in user's .lakeforge directory."""
        lakeforge_bash = project_path / ".lakeforge" / "scripts" / "bash"

        if not lakeforge_bash.exists():
            return False

        # Check if ANY .sh files exist (not just known scripts)
        # This catches custom scripts and ensures complete cleanup
        bash_scripts = list(lakeforge_bash.glob("*.sh"))
        return len(bash_scripts) > 0

    def can_apply(self, project_path: Path) -> tuple[bool, str]:
        """Migration can always be applied if bash scripts are detected."""
        return True, ""

    def apply(self, project_path: Path, dry_run: bool = False) -> MigrationResult:
        """Remove bash scripts and update templates."""
        changes: List[str] = []
        warnings: List[str] = []
        errors: List[str] = []

        # Step 1: Detect and remove bash scripts from .lakeforge
        bash_changes, bash_warnings = self._remove_bash_scripts(
            project_path, dry_run
        )
        changes.extend(bash_changes)
        warnings.extend(bash_warnings)

        # Step 2: Clean up bash scripts in worktrees
        worktree_changes = self._cleanup_worktree_bash_scripts(
            project_path, dry_run
        )
        changes.extend(worktree_changes)

        # Step 2.5: Remove obsolete task helpers
        tasks_changes, tasks_warnings = self._remove_tasks_helpers(
            project_path, dry_run
        )
        changes.extend(tasks_changes)
        warnings.extend(tasks_warnings)

        # Step 3: Update slash command templates
        template_changes, template_errors = self._update_command_templates(
            project_path, dry_run
        )
        changes.extend(template_changes)
        errors.extend(template_errors)

        # Note: Custom script detection now happens in _remove_bash_scripts()
        # before deletion, so users get warnings about custom scripts

        success = len(errors) == 0
        return MigrationResult(
            success=success,
            changes_made=changes,
            errors=errors,
            warnings=warnings,
        )

    def _remove_bash_scripts(
        self, project_path: Path, dry_run: bool
    ) -> Tuple[List[str], List[str]]:
        """Remove bash scripts from .lakeforge/scripts/bash/."""
        changes: List[str] = []
        warnings: List[str] = []

        lakeforge_bash = project_path / ".lakeforge" / "scripts" / "bash"

        if not lakeforge_bash.exists():
            warnings.append("No .lakeforge/scripts/bash/ directory found - already migrated?")
            return changes, warnings

        # First, detect custom scripts (not in PACKAGE_SCRIPTS) and warn user
        all_bash_scripts = list(lakeforge_bash.glob("*.sh"))
        custom_scripts = [s for s in all_bash_scripts if s.name not in self.PACKAGE_SCRIPTS]

        if custom_scripts:
            custom_names = [s.name for s in custom_scripts]
            warnings.append(f"Custom bash scripts detected: {', '.join(custom_names)}")
            warnings.append(
                "These custom scripts will be removed as part of the migration to Python-only. "
                "If you need this functionality, please migrate it manually before upgrading."
            )

        # Now delete ALL .sh files (including custom ones)
        # This ensures complete cleanup, matching PowerShell/worktree behavior
        scripts_removed = len(all_bash_scripts)

        for script in all_bash_scripts:
            if dry_run:
                changes.append(f"Would remove: .lakeforge/scripts/bash/{script.name}")
            else:
                script.unlink()
                changes.append(f"Removed: .lakeforge/scripts/bash/{script.name}")

        # Remove PowerShell equivalents if they exist
        lakeforge_ps = project_path / ".lakeforge" / "scripts" / "powershell"
        if lakeforge_ps.exists():
            ps_scripts = list(lakeforge_ps.glob("*.ps1"))
            if ps_scripts:
                for ps_script in ps_scripts:
                    if dry_run:
                        changes.append(f"Would remove: .lakeforge/scripts/powershell/{ps_script.name}")
                    else:
                        ps_script.unlink()
                        changes.append(f"Removed: .lakeforge/scripts/powershell/{ps_script.name}")
                    scripts_removed += 1

        # Remove directories if empty
        if not dry_run:
            if lakeforge_bash.exists() and not any(lakeforge_bash.iterdir()):
                lakeforge_bash.rmdir()
                changes.append("Removed empty: .lakeforge/scripts/bash/")
            if lakeforge_ps.exists() and not any(lakeforge_ps.iterdir()):
                lakeforge_ps.rmdir()
                changes.append("Removed empty: .lakeforge/scripts/powershell/")

        if scripts_removed > 0:
            changes.append(f"Total scripts removed: {scripts_removed}")
        else:
            warnings.append("No bash scripts found to remove - already migrated?")

        return changes, warnings

    def _cleanup_worktree_bash_scripts(
        self, project_path: Path, dry_run: bool
    ) -> List[str]:
        """Remove bash scripts from all worktrees."""
        changes: List[str] = []

        worktrees_dir = project_path / ".worktrees"
        if not worktrees_dir.exists():
            return changes

        for worktree in sorted(worktrees_dir.iterdir()):
            if not worktree.is_dir():
                continue

            wt_bash = worktree / ".lakeforge" / "scripts" / "bash"
            if not wt_bash.exists():
                continue

            scripts_found = list(wt_bash.glob("*.sh"))
            if scripts_found:
                if dry_run:
                    changes.append(f"Would remove {len(scripts_found)} scripts from worktree: {worktree.name}")
                else:
                    for script in scripts_found:
                        script.unlink()
                    if not any(wt_bash.iterdir()):
                        wt_bash.rmdir()
                    changes.append(f"Removed {len(scripts_found)} scripts from worktree: {worktree.name}")

        return changes

    def _remove_tasks_helpers(
        self, project_path: Path, dry_run: bool
    ) -> Tuple[List[str], List[str]]:
        """Remove obsolete .lakeforge/scripts/tasks/ directory."""
        changes: List[str] = []
        warnings: List[str] = []

        tasks_dir = project_path / ".lakeforge" / "scripts" / "tasks"
        if not tasks_dir.exists():
            return changes, warnings

        if dry_run:
            changes.append("Would remove .lakeforge/scripts/tasks/ (obsolete task helpers)")
            return changes, warnings

        try:
            shutil.rmtree(tasks_dir)
            changes.append("Removed .lakeforge/scripts/tasks/ (obsolete task helpers)")
        except OSError as e:
            warnings.append(f"Failed to remove .lakeforge/scripts/tasks/: {e}")

        return changes, warnings

    def _update_command_templates(
        self, project_path: Path, dry_run: bool
    ) -> Tuple[List[str], List[str]]:
        """Update slash command templates to use Python CLI."""
        changes: List[str] = []
        errors: List[str] = []

        # Templates in .lakeforge/templates/command-templates/
        templates_dir = project_path / ".lakeforge" / "templates" / "command-templates"

        if not templates_dir.exists():
            # Templates not in expected location - might be from old package install
            # This is expected for projects initialized with older package versions
            # Templates will be fixed when they upgrade to v0.10.9+ which has repair migration
            changes.append(
                "Templates directory not found at .lakeforge/templates/command-templates/. "
                "This is expected for projects initialized with older package versions. "
                "Run 'lakeforge upgrade' after upgrading to v0.10.9+ to repair templates."
            )
            return changes, []  # No errors, defer to repair migration

        templates_updated = 0
        for template_path in sorted(templates_dir.glob("*.md")):
            try:
                updated, replacements = self._update_template_file(
                    template_path, dry_run
                )
                if updated:
                    templates_updated += 1
                    if dry_run:
                        changes.append(f"Would update: {template_path.name} ({replacements} replacements)")
                    else:
                        changes.append(f"Updated: {template_path.name} ({replacements} replacements)")
            except Exception as e:
                errors.append(f"Error updating {template_path.name}: {e}")

        if templates_updated > 0:
            changes.append(f"Total templates updated: {templates_updated}")

        return changes, errors

    def _update_template_file(
        self, template_path: Path, dry_run: bool
    ) -> Tuple[bool, int]:
        """Update a single template file with bash → Python replacements."""
        content = template_path.read_text(encoding="utf-8")
        original_content = content
        replacements_made = 0

        # Apply all replacements
        for pattern, replacement in self.COMMAND_REPLACEMENTS.items():
            new_content, count = re.subn(pattern, replacement, content)
            if count > 0:
                content = new_content
                replacements_made += count

        # Write if changes were made
        if content != original_content:
            if not dry_run:
                template_path.write_text(content, encoding="utf-8")
            return True, replacements_made

        return False, 0

    def _detect_custom_modifications(self, project_path: Path) -> List[str]:
        """Detect custom modifications to bash scripts."""
        warnings: List[str] = []

        lakeforge_bash = project_path / ".lakeforge" / "scripts" / "bash"
        if not lakeforge_bash.exists():
            return warnings

        # Look for non-standard scripts (not in PACKAGE_SCRIPTS)
        custom_scripts = []
        for script_path in lakeforge_bash.glob("*.sh"):
            if script_path.name not in self.PACKAGE_SCRIPTS:
                custom_scripts.append(script_path.name)

        if custom_scripts:
            warnings.append(
                f"Custom bash scripts detected: {', '.join(custom_scripts)}"
            )
            warnings.append(
                "These scripts will NOT be removed automatically. "
                "Please migrate them manually or remove if no longer needed."
            )

        return warnings
