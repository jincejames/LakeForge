"""Migration: Update lakehouse templates with resource attribution tags (v0.14.0)."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from ..registry import MigrationRegistry
from .base import BaseMigration, MigrationResult


@MigrationRegistry.register
class TelemetryAttributionMigration(BaseMigration):
    """Update lakehouse templates with resource attribution instructions.

    This migration updates the databricks-lakehouse-buildout mission templates
    with resource attribution sections that instruct AI agents to tag every
    Databricks resource with product=lakeforge custom_tags.
    """

    migration_id = "0.14.0_telemetry_attribution"
    description = "Add resource attribution tags to lakehouse templates"
    target_version = "0.14.0"

    def detect(self, project_path: Path) -> bool:
        """Check if any lakehouse template needs attribution update."""
        lakeforge_dir = project_path / ".lakeforge"
        if not lakeforge_dir.exists():
            return False

        cmd_dir = (
            lakeforge_dir / "missions" / "databricks-lakehouse-buildout"
            / "command-templates"
        )
        if not cmd_dir.exists():
            return False

        try:
            for template_name in ["implement.md", "constitution.md", "review.md"]:
                template_path = cmd_dir / template_name
                if not template_path.exists():
                    continue
                content = template_path.read_text(encoding="utf-8")
                if "Resource Attribution" not in content:
                    return True
            return False
        except OSError:
            return False

    def can_apply(self, project_path: Path) -> tuple[bool, str]:
        """Check if migration can be safely applied."""
        lakeforge_dir = project_path / ".lakeforge"
        if not lakeforge_dir.exists():
            return False, "Not a lakeforge project (.lakeforge/ not found)"

        source = self._find_source_dir()
        if source is None:
            return (
                False,
                "Could not locate lakehouse mission source templates in lakeforge installation. "
                "This may indicate an incomplete installation.",
            )

        return True, ""

    def apply(self, project_path: Path, dry_run: bool = False) -> MigrationResult:
        """Apply resource attribution to lakehouse templates."""
        changes: list[str] = []
        errors: list[str] = []

        lakehouse_dir = project_path / ".lakeforge" / "missions" / "databricks-lakehouse-buildout"
        if not lakehouse_dir.exists():
            return MigrationResult(
                success=True,
                changes_made=["Lakehouse mission not installed (skipped)"],
            )

        # Evaluate each template independently to avoid partial-upgrade states
        cmd_dir = lakehouse_dir / "command-templates"
        templates_needing_update: list[str] = []
        for template_name in ["implement.md", "constitution.md", "review.md"]:
            dest = cmd_dir / template_name
            if not dest.exists():
                continue
            try:
                if "Resource Attribution" not in dest.read_text(encoding="utf-8"):
                    templates_needing_update.append(template_name)
            except OSError as e:
                errors.append(f"Failed to read {template_name}: {e}")

        if errors:
            return MigrationResult(success=False, errors=errors)

        if not templates_needing_update:
            return MigrationResult(
                success=True,
                changes_made=["Lakehouse templates already have resource attribution (skipped)"],
            )

        if dry_run:
            return MigrationResult(
                success=True,
                changes_made=[f"Would update {', '.join(templates_needing_update)} with resource attribution"],
            )

        source_dir = self._find_source_dir()
        if source_dir is None:
            return MigrationResult(
                success=False,
                errors=["Could not find lakehouse mission source templates in lakeforge installation"],
            )

        import shutil

        updated = 0
        for template_name in templates_needing_update:
            source = source_dir / "command-templates" / template_name
            dest = cmd_dir / template_name
            try:
                if source.exists():
                    shutil.copy2(source, dest)
                    updated += 1
            except OSError as e:
                errors.append(f"Failed to copy {template_name}: {e}")

        if errors:
            return MigrationResult(success=False, changes_made=changes, errors=errors)

        changes.append(f"Updated {updated} lakehouse templates with resource attribution")
        return MigrationResult(success=True, changes_made=changes)

    def _find_source_dir(self) -> Optional[Path]:
        """Find the lakehouse mission source in the lakeforge installation."""
        source_dir = Path(__file__).parent.parent.parent / "missions" / "databricks-lakehouse-buildout"
        if source_dir.exists() and (source_dir / "mission.yaml").exists():
            return source_dir
        return None
