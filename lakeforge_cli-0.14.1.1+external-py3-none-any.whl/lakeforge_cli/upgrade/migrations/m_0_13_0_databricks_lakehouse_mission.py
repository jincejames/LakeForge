"""Migration: Install databricks-lakehouse-buildout mission to user projects (v0.13.0)."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Optional

from ..registry import MigrationRegistry
from .base import BaseMigration, MigrationResult


@MigrationRegistry.register
class InstallDatabricksLakehouseMission(BaseMigration):
    """Install the databricks-lakehouse-buildout mission to user projects.

    This migration copies the databricks-lakehouse-buildout mission from the lakeforge
    installation (src/lakeforge_cli/missions/databricks-lakehouse-buildout/) to the user's
    project (.lakeforge/missions/databricks-lakehouse-buildout/).

    The databricks-lakehouse-buildout mission enables users to build data lakehouse solutions
    on Databricks with medallion architecture (Bronze → Silver → Gold) and the packaged
    mission guidance available in the installed lakeforge version.
    """

    migration_id = "0.13.0_databricks_lakehouse_mission"
    description = "Install Databricks Lakehouse Buildout mission for medallion architecture development"
    target_version = "0.13.0"

    def detect(self, project_path: Path) -> bool:
        """Detect if databricks-lakehouse-buildout mission needs to be installed.

        Args:
            project_path: Root directory of user's lakeforge project

        Returns:
            True if mission is missing, False if already installed
        """
        lakeforge_dir = project_path / ".lakeforge"

        if not lakeforge_dir.exists():
            # Not a lakeforge project, migration doesn't apply
            return False

        missions_dir = lakeforge_dir / "missions"

        if not missions_dir.exists():
            # Missions directory doesn't exist (very old project)
            # Migration should run to create it
            return True

        lakehouse_mission_dir = missions_dir / "databricks-lakehouse-buildout"

        # Check if mission already exists
        if lakehouse_mission_dir.exists() and (lakehouse_mission_dir / "mission.yaml").exists():
            # Already installed
            return False

        # Mission is missing, migration should run
        return True

    def can_apply(self, project_path: Path) -> tuple[bool, str]:
        """Check if migration can be safely applied.

        Args:
            project_path: Root of the project

        Returns:
            (can_apply, reason) - True if safe, False with explanation if not
        """
        # Check if source mission exists
        source_mission = self._find_source_mission()
        if source_mission is None:
            return (
                False,
                "Could not locate databricks-lakehouse-buildout mission source in lakeforge installation. "
                "This may indicate an incomplete installation.",
            )

        return True, ""

    def apply(self, project_path: Path, dry_run: bool = False) -> MigrationResult:
        """Copy databricks-lakehouse-buildout mission to user project.

        Args:
            project_path: Root directory of user's lakeforge project
            dry_run: If True, only simulate changes

        Returns:
            MigrationResult indicating success or failure
        """
        changes: list[str] = []
        errors: list[str] = []

        lakeforge_dir = project_path / ".lakeforge"
        missions_dir = lakeforge_dir / "missions"

        # Find source mission
        source_mission = self._find_source_mission()

        if source_mission is None:
            errors.append("Could not find databricks-lakehouse-buildout mission source in lakeforge installation")
            return MigrationResult(success=False, errors=errors)

        # Destination
        dest_mission = missions_dir / "databricks-lakehouse-buildout"

        # Check if destination already exists
        if dest_mission.exists() and (dest_mission / "mission.yaml").exists():
            return MigrationResult(
                success=True,
                changes_made=["Databricks Lakehouse Buildout mission already installed (skipped)"]
            )

        # Ensure missions directory exists
        if not missions_dir.exists():
            if dry_run:
                changes.append("Would create .lakeforge/missions/ directory")
            else:
                missions_dir.mkdir(parents=True, exist_ok=True)
                changes.append("Created .lakeforge/missions/ directory")

        # Copy mission directory
        if dry_run:
            changes.append("Would copy databricks-lakehouse-buildout mission to .lakeforge/missions/databricks-lakehouse-buildout/")
        else:
            try:
                shutil.copytree(source_mission, dest_mission)

                # Count copied files for reporting
                copied_files = list(dest_mission.rglob("*"))
                file_count = len([f for f in copied_files if f.is_file()])

                changes.append(f"Copied databricks-lakehouse-buildout mission ({file_count} files)")

            except Exception as e:
                errors.append(f"Failed to copy databricks-lakehouse-buildout mission: {e}")
                return MigrationResult(success=False, errors=errors)

        return MigrationResult(success=True, changes_made=changes)

    def _find_source_mission(self) -> Optional[Path]:
        """Find the databricks-lakehouse-buildout mission in lakeforge's installation.

        Returns:
            Path to source mission directory, or None if not found
        """
        # The source is relative to this migration file
        migrations_dir = Path(__file__).parent
        src_dir = migrations_dir.parent.parent  # Up to src/lakeforge_cli/
        source_mission = src_dir / "missions" / "databricks-lakehouse-buildout"

        if source_mission.exists() and (source_mission / "mission.yaml").exists():
            return source_mission

        return None
