"""Migration: Rename .specify/ to .lakeforge/ and /specs/ to /lakeforge-specs/."""

from __future__ import annotations

import shutil
from pathlib import Path

from ..registry import MigrationRegistry
from .base import BaseMigration, MigrationResult


@MigrationRegistry.register
class SpecifyToKittifyMigration(BaseMigration):
    """Migrate from .specify/ to .lakeforge/ and /specs/ to /lakeforge-specs/.

    This migration handles the rebranding from the original "specify"
    naming to "lakeforge" naming introduced in v0.2.0.
    """

    migration_id = "0.2.0_specify_to_lakeforge"
    description = "Rename .specify/ to .lakeforge/ and /specs/ to /lakeforge-specs/"
    target_version = "0.2.0"

    def detect(self, project_path: Path) -> bool:
        """Check if project uses old .specify/ directory."""
        return (project_path / ".specify").exists()

    def can_apply(self, project_path: Path) -> tuple[bool, str]:
        """Check if migration can be safely applied."""
        specify_dir = project_path / ".specify"
        lakeforge_dir = project_path / ".lakeforge"

        if not specify_dir.exists():
            return False, ".specify/ directory does not exist"

        if lakeforge_dir.exists():
            return False, ".lakeforge/ already exists - manual merge required"

        specs_dir = project_path / "specs"
        kitty_specs_dir = project_path / "lakeforge-specs"

        if specs_dir.exists() and kitty_specs_dir.exists():
            return False, "Both /specs/ and /lakeforge-specs/ exist - manual merge required"

        return True, ""

    def apply(self, project_path: Path, dry_run: bool = False) -> MigrationResult:
        """Apply the migration."""
        changes: list[str] = []
        errors: list[str] = []

        specify_dir = project_path / ".specify"
        lakeforge_dir = project_path / ".lakeforge"
        specs_dir = project_path / "specs"
        kitty_specs_dir = project_path / "lakeforge-specs"

        # Rename .specify/ to .lakeforge/
        if specify_dir.exists():
            if dry_run:
                changes.append(f"Would rename {specify_dir} to {lakeforge_dir}")
            else:
                try:
                    shutil.move(str(specify_dir), str(lakeforge_dir))
                    changes.append(f"Renamed {specify_dir} to {lakeforge_dir}")
                except OSError as e:
                    errors.append(f"Failed to rename .specify/ to .lakeforge/: {e}")

        # Rename /specs/ to /lakeforge-specs/
        if specs_dir.exists() and not kitty_specs_dir.exists():
            if dry_run:
                changes.append(f"Would rename {specs_dir} to {kitty_specs_dir}")
            else:
                try:
                    shutil.move(str(specs_dir), str(kitty_specs_dir))
                    changes.append(f"Renamed {specs_dir} to {kitty_specs_dir}")
                except OSError as e:
                    errors.append(f"Failed to rename /specs/ to /lakeforge-specs/: {e}")

        success = len(errors) == 0
        return MigrationResult(success=success, changes_made=changes, errors=errors)
