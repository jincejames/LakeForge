"""Migration: Refresh Databricks mission with well-architected lakehouse pillars."""

from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import Optional

from ..registry import MigrationRegistry
from .base import BaseMigration, MigrationResult


@MigrationRegistry.register
class RefreshDatabricksWellArchitectedMission(BaseMigration):
    """Refresh installed Databricks lakehouse mission templates.

    Existing project copies under `.lakeforge/missions/` are generated mission
    assets. Refreshing the whole mission keeps command templates, artifact
    templates, and `mission.yaml` aligned with the packaged source.
    """

    migration_id = "0.14.1_databricks_well_architected_mission"
    description = "Refresh Databricks mission with well-architected lakehouse pillars"
    target_version = "0.14.1"

    MISSION_NAME = "databricks-lakehouse-buildout"
    WELL_ARCHITECTED_MARKER = "Additional Mandatory Control (Databricks well-architected lakehouse framework)"
    REQUIRED_TEMPLATE_MARKERS = (
        (
            "command-templates/constitution.md",
            "Additional Mandatory Control: Databricks Well-Architected Framework",
        ),
        (
            "command-templates/review.md",
            "Additional Mandatory Control: Databricks Well-Architected Framework",
        ),
        (
            "command-templates/accept.md",
            "Additional Mandatory Control: Databricks Well-Architected Final Verification",
        ),
        (
            "command-templates/implement.md",
            "Additional Mandatory Well-Architected Checkpoint",
        ),
    )

    def detect(self, project_path: Path) -> bool:
        """Check if an installed Databricks mission needs a refresh."""
        mission_dir = project_path / ".lakeforge" / "missions" / self.MISSION_NAME
        mission_yaml = mission_dir / "mission.yaml"

        if not mission_dir.exists():
            return False

        if self._file_missing_marker(mission_yaml, self.WELL_ARCHITECTED_MARKER):
            return True

        for relative_path, marker in self.REQUIRED_TEMPLATE_MARKERS:
            if self._file_missing_marker(mission_dir / relative_path, marker):
                return True

        return False

    def _file_missing_marker(self, path: Path, marker: str) -> bool:
        """Treat missing, unreadable, or stale generated assets as refreshable."""
        if not path.exists():
            return True

        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError):
            return True

        return marker not in content

    def can_apply(self, project_path: Path) -> tuple[bool, str]:
        """Check whether the packaged source mission is available."""
        if not (project_path / ".lakeforge").exists():
            return False, "Not a lakeforge project (.lakeforge/ not found)"

        if self._find_source_mission() is None:
            return (
                False,
                "Could not locate databricks-lakehouse-buildout mission source in lakeforge installation.",
            )

        return True, ""

    def apply(self, project_path: Path, dry_run: bool = False) -> MigrationResult:
        """Replace the installed mission copy with the packaged source mission."""
        changes: list[str] = []
        errors: list[str] = []
        warnings: list[str] = []

        source_mission = self._find_source_mission()
        if source_mission is None:
            return MigrationResult(
                success=False,
                errors=["Could not find databricks-lakehouse-buildout mission source"],
            )

        missions_dir = project_path / ".lakeforge" / "missions"
        dest_mission = missions_dir / self.MISSION_NAME

        if not dest_mission.exists():
            return MigrationResult(
                success=True,
                changes_made=["Databricks Lakehouse Buildout mission not installed (skipped)"],
            )

        if dry_run:
            return MigrationResult(
                success=True,
                changes_made=[
                    "Would refresh .lakeforge/missions/databricks-lakehouse-buildout/ "
                    "with well-architected lakehouse pillar templates"
                ],
            )

        temp_root: Optional[Path] = None
        temp_mission: Optional[Path] = None
        backup_root: Optional[Path] = None
        backup_mission: Optional[Path] = None

        try:
            temp_root = Path(
                tempfile.mkdtemp(
                    prefix=f".{self.MISSION_NAME}.",
                    suffix=".tmp",
                    dir=missions_dir,
                )
            )
            temp_mission = temp_root / self.MISSION_NAME
            shutil.copytree(source_mission, temp_mission)

            backup_root = Path(
                tempfile.mkdtemp(
                    prefix=f".{self.MISSION_NAME}.",
                    suffix=".backup",
                    dir=missions_dir,
                )
            )
            backup_mission = backup_root / self.MISSION_NAME

            dest_mission.rename(backup_mission)
            temp_mission.rename(dest_mission)
            temp_mission = None

            self._cleanup_directory(backup_root, "backup directory", warnings)
            backup_mission = None
            backup_root = None
            self._cleanup_directory(temp_root, "temporary staging directory", warnings)
            temp_root = None
        except (OSError, shutil.Error) as e:
            if (
                backup_mission is not None
                and backup_mission.exists()
                and not dest_mission.exists()
            ):
                try:
                    backup_mission.rename(dest_mission)
                    backup_mission = None
                except OSError as restore_error:
                    errors.append(
                        "Failed to restore existing databricks-lakehouse-buildout "
                        f"mission after refresh error: {restore_error}"
                    )

            if temp_root is not None and temp_root.exists():
                self._cleanup_directory(
                    temp_root, "temporary staging directory", warnings
                )
            if (
                backup_root is not None
                and backup_root.exists()
                and (
                    backup_mission is None
                    or not backup_mission.exists()
                    or dest_mission.exists()
                )
            ):
                self._cleanup_directory(backup_root, "backup directory", warnings)

            errors.append(f"Failed to refresh databricks-lakehouse-buildout mission: {e}")

        if errors:
            return MigrationResult(
                success=False,
                changes_made=changes,
                errors=errors,
                warnings=warnings,
            )

        copied_files = [path for path in dest_mission.rglob("*") if path.is_file()]
        changes.append(
            "Refreshed Databricks Lakehouse Buildout mission "
            f"with well-architected pillar templates ({len(copied_files)} files)"
        )
        return MigrationResult(success=True, changes_made=changes, warnings=warnings)

    def _cleanup_directory(
        self, path: Path, description: str, warnings: list[str]
    ) -> None:
        """Remove a temporary migration directory, reporting failures to users."""
        try:
            shutil.rmtree(path)
        except (OSError, shutil.Error) as e:
            warnings.append(
                f"Could not remove {description} at {path}: {e}. "
                "You can remove it manually after verifying the migration result."
            )

    def _find_source_mission(self) -> Optional[Path]:
        """Find the packaged Databricks mission source directory."""
        source_mission = (
            Path(__file__).parent.parent.parent / "missions" / self.MISSION_NAME
        )
        if source_mission.exists() and (source_mission / "mission.yaml").exists():
            return source_mission
        return None
