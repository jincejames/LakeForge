"""Configuration constants shared across the Lakeforge CLI."""

from __future__ import annotations

AI_CHOICES = {
    "copilot": "GitHub Copilot",
    "claude": "Claude Code",
    "gemini": "Gemini CLI",
    "cursor": "Cursor",
    "qwen": "Qwen Code",
    "opencode": "opencode",
    "codex": "Codex CLI",
    "windsurf": "Windsurf",
    "kilocode": "Kilo Code",
    "auggie": "Auggie CLI",
    "roo": "Roo Code",
    "q": "Amazon Q Developer CLI",
}

MISSION_CHOICES = {
    "software-dev": "Software Development",
    "research": "Deep Research",
    "databricks-lakehouse-buildout": "Databricks Lakehouse Buildout",
}

DEFAULT_MISSION_KEY = "software-dev"

AGENT_TOOL_REQUIREMENTS: dict[str, tuple[str, str]] = {
    "claude": ("claude", "https://docs.anthropic.com/en/docs/claude-code/setup"),
    "gemini": ("gemini", "https://github.com/google-gemini/gemini-cli"),
    "qwen": ("qwen", "https://github.com/QwenLM/qwen-code"),
    "opencode": ("opencode", "https://opencode.ai"),
    "codex": ("codex", "https://github.com/openai/codex"),
    "auggie": ("auggie", "https://docs.augmentcode.com/cli/setup-auggie/install-auggie-cli"),
    "q": ("q", "https://aws.amazon.com/developer/learning/q-developer-cli/"),
}

SCRIPT_TYPE_CHOICES = {"sh": "POSIX Shell (bash/zsh)", "ps": "PowerShell"}

DEFAULT_TEMPLATE_REPO = "lakeforge/lakeforge"

# IDE-integrated agents that don't require CLI installation
IDE_AGENTS = {"cursor", "windsurf", "copilot", "kilocode"}

AGENT_COMMAND_CONFIG: dict[str, dict[str, str]] = {
    "claude": {"dir": ".claude/commands", "ext": "md", "arg_format": "$ARGUMENTS"},
    "gemini": {"dir": ".gemini/commands", "ext": "toml", "arg_format": "{{args}}"},
    "copilot": {"dir": ".github/prompts", "ext": "prompt.md", "arg_format": "$ARGUMENTS"},
    "cursor": {"dir": ".cursor/commands", "ext": "md", "arg_format": "$ARGUMENTS"},
    "qwen": {"dir": ".qwen/commands", "ext": "toml", "arg_format": "{{args}}"},
    "opencode": {"dir": ".opencode/command", "ext": "md", "arg_format": "$ARGUMENTS"},
    "windsurf": {"dir": ".windsurf/workflows", "ext": "md", "arg_format": "$ARGUMENTS"},
    "codex": {"dir": ".codex/prompts", "ext": "md", "arg_format": "$ARGUMENTS"},
    "kilocode": {"dir": ".kilocode/workflows", "ext": "md", "arg_format": "$ARGUMENTS"},
    "auggie": {"dir": ".augment/commands", "ext": "md", "arg_format": "$ARGUMENTS"},
    "roo": {"dir": ".roo/commands", "ext": "md", "arg_format": "$ARGUMENTS"},
    "q": {"dir": ".amazonq/prompts", "ext": "md", "arg_format": "$ARGUMENTS"},
}

# ai-dev-kit dependency configuration
# Used by --package lakehouse-buildout to install Databricks skills + MCP server
# via ai-dev-kit's installer. Override per-project in .lakeforge/config.yaml under
# `ai_dev_kit.version`.
AI_DEV_KIT_REPO = "databricks-solutions/ai-dev-kit"
# ai-dev-kit's GitHub tags use a "v" prefix (e.g. "v0.1.10"), matching what
# install.sh fetches when no --branch is passed via the GitHub releases API.
AI_DEV_KIT_DEFAULT_VERSION = "v0.1.10"
AI_DEV_KIT_INSTALL_SCRIPT_URL = (
    f"https://raw.githubusercontent.com/{AI_DEV_KIT_REPO}/{{tag}}/install.sh"
)
# Agents supported by ai-dev-kit's install.sh --tools flag.
# Lakeforge supports more agents than ai-dev-kit; packages that require
# ai-dev-kit (see PACKAGE_CONFIG in cli/commands/init.py) must select at least
# one of these.
AI_DEV_KIT_SUPPORTED_AGENTS: frozenset[str] = frozenset(
    {"claude", "cursor", "copilot", "codex", "gemini"}
)
# Skills profiles offered by ai-dev-kit's installer (--skills-profile flag).
# Each lakeforge package picks one (or supplies a custom skill list) via
# PACKAGE_CONFIG. Listed here for reference and validation.
AI_DEV_KIT_SKILLS_PROFILES: frozenset[str] = frozenset(
    {"all", "data-engineer", "ai-ml-engineer", "app-developer"}
)

BANNER = """
╔══════════════════════════════════════════════════════════════════════════════════╗
║                                                                                  ║
║   ██       █████  ██   ██ ███████ ███████  ██████  ██████   ██████  ███████      ║
║   ██      ██   ██ ██  ██  ██      ██      ██    ██ ██   ██ ██       ██           ║
║   ██      ███████ █████   █████   █████   ██    ██ ██████  ██   ███ █████        ║
║   ██      ██   ██ ██  ██  ██      ██      ██    ██ ██   ██ ██    ██ ██           ║
║   ███████ ██   ██ ██   ██ ███████ ██       ██████  ██   ██  ██████  ███████      ║
║                                                                                  ║
║                         ⚒️  Spec-Driven Development  ⚒️                           ║
║                                                                                  ║
╚══════════════════════════════════════════════════════════════════════════════════╝
"""

__all__ = [
    "AI_CHOICES",
    "MISSION_CHOICES",
    "DEFAULT_MISSION_KEY",
    "AGENT_TOOL_REQUIREMENTS",
    "SCRIPT_TYPE_CHOICES",
    "DEFAULT_TEMPLATE_REPO",
    "AGENT_COMMAND_CONFIG",
    "IDE_AGENTS",
    "BANNER",
    "AI_DEV_KIT_REPO",
    "AI_DEV_KIT_DEFAULT_VERSION",
    "AI_DEV_KIT_INSTALL_SCRIPT_URL",
    "AI_DEV_KIT_SUPPORTED_AGENTS",
    "AI_DEV_KIT_SKILLS_PROFILES",
]
